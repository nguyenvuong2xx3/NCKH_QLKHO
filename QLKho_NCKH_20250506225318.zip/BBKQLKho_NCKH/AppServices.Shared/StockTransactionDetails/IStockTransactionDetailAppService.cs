﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using System;
using QLKho_NCKH.QLKho_NCKH.Dto;
using QLKho_NCKH.StockTransactionDetails.Dto;
using System.Threading.Tasks;
using System.IO;

namespace QLKho_NCKH.StockTransactionDetails
{

public interface IStockTransactionDetailAppService : IApplicationService
{
	Task<StockTransactionDetailEditDto> CreateStockTransactionDetail(StockTransactionDetailCreatingInput input);

	Task<StockTransactionDetailEditDto> GetStockTransactionDetail(int id);

	Task<StockTransactionDetailEditDto> EditStockTransactionDetail(StockTransactionDetailEditDto input);

	Task<PagedResultDto<StockTransactionDetailListDto>> GetStockTransactionDetails(GetStockTransactionDetailsInput input);

	Task DeleteStockTransactionDetail(int Id);



		}
	}
