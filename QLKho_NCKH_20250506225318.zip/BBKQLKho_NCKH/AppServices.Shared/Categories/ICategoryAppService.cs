﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using System;
using QLKho_NCKH.QLKho_NCKH.Dto;
using QLKho_NCKH.Categories.Dto;
using System.Threading.Tasks;
using System.IO;

namespace QLKho_NCKH.Categories
{

public interface ICategoryAppService : IApplicationService
{
	Task<CategoryEditDto> CreateCategory(CategoryCreatingInput input);

	Task<CategoryEditDto> GetCategory(int id);

	Task<CategoryEditDto> EditCategory(CategoryEditDto input);

	Task<PagedResultDto<CategoryListDto>> GetCategories(GetCategoriesInput input);

	Task DeleteCategory(int Id);



		}
	}
