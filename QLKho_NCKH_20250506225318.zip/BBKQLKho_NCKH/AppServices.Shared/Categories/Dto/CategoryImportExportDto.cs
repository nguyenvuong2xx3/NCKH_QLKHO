﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.Categories.Dto {

public class CategoryImportDto {
   public string Id {get;set;}
   public string Name {get;set;}
   public string Description {get;set;}
   public string ParentId {get;set;}

}

public class GetCategoriesExportOptionsInput : GetCategoriesInput
{
	public int ExportFileType { get; set; } // 1 excel, 2, csv, 3, json
	public bool IsDisplayName { get; set; }
	public bool IsDisplayDescription { get; set; }
	public bool IsDisplayParentId { get; set; }

}
}
