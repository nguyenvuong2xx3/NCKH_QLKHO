﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using System;
using QLKho_NCKH.QLKho_NCKH.Dto;
using QLKho_NCKH.Warehouses.Dto;
using System.Threading.Tasks;
using System.IO;

namespace QLKho_NCKH.Warehouses
{

public interface IWarehousAppService : IApplicationService
{
	Task<WarehousEditDto> CreateWarehous(WarehousCreatingInput input);

	Task<WarehousEditDto> GetWarehous(int id);

	Task<WarehousEditDto> EditWarehous(WarehousEditDto input);

	Task<PagedResultDto<WarehousListDto>> GetWarehouses(GetWarehousesInput input);

	Task DeleteWarehous(int Id);



		}
	}
