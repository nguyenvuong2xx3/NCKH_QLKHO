﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.Warehouses.Dto {

public class WarehousImportDto {
   public string Id {get;set;}
   public string Code {get;set;}
   public string Name {get;set;}
   public string Location {get;set;}
   public string TotalArea {get;set;}
   public string IsActive {get;set;}

}

public class GetWarehousesExportOptionsInput : GetWarehousesInput
{
	public int ExportFileType { get; set; } // 1 excel, 2, csv, 3, json
	public bool IsDisplayCode { get; set; }
	public bool IsDisplayName { get; set; }
	public bool IsDisplayLocation { get; set; }
	public bool IsDisplayTotalArea { get; set; }
	public bool IsDisplayIsActive { get; set; }

}
}
