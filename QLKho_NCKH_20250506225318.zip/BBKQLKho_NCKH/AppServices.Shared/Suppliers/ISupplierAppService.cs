﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using System;
using QLKho_NCKH.QLKho_NCKH.Dto;
using QLKho_NCKH.Suppliers.Dto;
using System.Threading.Tasks;
using System.IO;

namespace QLKho_NCKH.Suppliers
{

public interface ISupplierAppService : IApplicationService
{
	Task<SupplierEditDto> CreateSupplier(SupplierCreatingInput input);

	Task<SupplierEditDto> GetSupplier(int id);

	Task<SupplierEditDto> EditSupplier(SupplierEditDto input);

	Task<PagedResultDto<SupplierListDto>> GetSuppliers(GetSuppliersInput input);

	Task DeleteSupplier(int Id);



		}
	}
