﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.Suppliers.Dto {

public class SupplierImportDto {
   public string Id {get;set;}
   public string Code {get;set;}
   public string Name {get;set;}
   public string Address {get;set;}
   public string PhoneNumber {get;set;}
   public string Email {get;set;}
   public string TaxCode {get;set;}
   public string IsActive {get;set;}

}

public class GetSuppliersExportOptionsInput : GetSuppliersInput
{
	public int ExportFileType { get; set; } // 1 excel, 2, csv, 3, json
	public bool IsDisplayCode { get; set; }
	public bool IsDisplayName { get; set; }
	public bool IsDisplayAddress { get; set; }
	public bool IsDisplayPhoneNumber { get; set; }
	public bool IsDisplayEmail { get; set; }
	public bool IsDisplayTaxCode { get; set; }
	public bool IsDisplayIsActive { get; set; }

}
}
