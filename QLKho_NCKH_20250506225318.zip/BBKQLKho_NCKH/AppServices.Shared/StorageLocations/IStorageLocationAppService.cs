﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using System;
using QLKho_NCKH.QLKho_NCKH.Dto;
using QLKho_NCKH.StorageLocations.Dto;
using System.Threading.Tasks;
using System.IO;

namespace QLKho_NCKH.StorageLocations
{

public interface IStorageLocationAppService : IApplicationService
{
	Task<StorageLocationEditDto> CreateStorageLocation(StorageLocationCreatingInput input);

	Task<StorageLocationEditDto> GetStorageLocation(int id);

	Task<StorageLocationEditDto> EditStorageLocation(StorageLocationEditDto input);

	Task<PagedResultDto<StorageLocationListDto>> GetStorageLocations(GetStorageLocationsInput input);

	Task DeleteStorageLocation(int Id);



		}
	}
