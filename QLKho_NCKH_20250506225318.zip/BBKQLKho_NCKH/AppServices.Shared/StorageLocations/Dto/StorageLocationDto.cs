﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using BBK.SaaS.Dto;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.StorageLocations.Dto {

public class StorageLocationCreatingInput {
   public string Code {get;set;}
   public int WarehouseId {get;set;}
   public decimal Capacity {get;set;}
   public decimal CurrentVolume {get;set;}
   public bool IsAvailable {get;set;}

}

public class StorageLocationEditDto: EntityDto<int> {
   public string Code {get;set;}
   public int WarehouseId {get;set;}
   public decimal Capacity {get;set;}
   public decimal CurrentVolume {get;set;}
   public bool IsAvailable {get;set;}

}

public class GetStorageLocationsInput : PagedAndSortedInputDto, IShouldNormalize
{
	public string Filter { get; set; }

	public DateTime? StartDate { get; set; }

	public DateTime? EndDate { get; set; }

	 public int? WarehouseId {get;set;}
	public decimal? Capacity {get;set;}
	public decimal? CurrentVolume {get;set;}
	



	public void Normalize()
	{
		if (Sorting.IsNullOrWhiteSpace())
		{
			Sorting = "CreationTime DESC";
		}
	}
}
public class StorageLocationListDto : AuditedEntityDto<int> {
  public string Code {get;set;}
  public int WarehouseId {get;set;}
  public decimal Capacity {get;set;}
  public decimal CurrentVolume {get;set;}
  public bool IsAvailable {get;set;}

  public StorageLocationListDto()
  {
  }
}
  public class FileOutputDto
  {
    public string FileName { get; set; }
    public string FileUrl { get; set; }
    public string ContentType { get; set; }

    public FileOutputDto(string fileName, string fileUrl, string contentType)
    {
      FileName = fileName;
      FileUrl = fileUrl;
      ContentType = contentType;
    }

    public FileOutputDto(string fileName)
    {
      FileName = fileName;
    }

    public FileOutputDto(string fileName, string contentType)
    {
      FileName = Path.GetFileName(fileName);
      ContentType = contentType;
      //FileUrl = fileUrl;
    }
  }

  public class FileDownloadDto(string fileName, string contentType, byte[] bytes) : FileOutputDto(fileName, contentType)
  {
    public byte[] Bytes { get; set; } = bytes;
  }
}
