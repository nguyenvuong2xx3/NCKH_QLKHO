﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.StorageLocations.Dto {

public class StorageLocationImportDto {
   public string Id {get;set;}
   public string Code {get;set;}
   public string WarehouseId {get;set;}
   public string Capacity {get;set;}
   public string CurrentVolume {get;set;}
   public string IsAvailable {get;set;}

}

public class GetStorageLocationsExportOptionsInput : GetStorageLocationsInput
{
	public int ExportFileType { get; set; } // 1 excel, 2, csv, 3, json
	public bool IsDisplayCode { get; set; }
	public bool IsDisplayWarehouseId { get; set; }
	public bool IsDisplayCapacity { get; set; }
	public bool IsDisplayCurrentVolume { get; set; }
	public bool IsDisplayIsAvailable { get; set; }

}
}
