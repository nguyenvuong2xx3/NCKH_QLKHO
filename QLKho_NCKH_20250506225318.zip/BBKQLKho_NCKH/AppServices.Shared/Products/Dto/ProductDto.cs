﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using BBK.SaaS.Dto;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.Products.Dto {

public class ProductCreatingInput {
   public string Code {get;set;}
   public string Name {get;set;}
   public string Description {get;set;}
   public int? CategoryId {get;set;}
   public string Barcode {get;set;}
   public string Unit {get;set;}
   public decimal Weight {get;set;}
   public decimal Volume {get;set;}
   public bool IsActive {get;set;}
   public int? SupplierId {get;set;}
   public string Image {get;set;}

}

public class ProductEditDto: EntityDto<int> {
   public string Code {get;set;}
   public string Name {get;set;}
   public string Description {get;set;}
   public int? CategoryId {get;set;}
   public string Barcode {get;set;}
   public string Unit {get;set;}
   public decimal Weight {get;set;}
   public decimal Volume {get;set;}
   public bool IsActive {get;set;}
   public int? SupplierId {get;set;}
   public string Image {get;set;}

}

public class GetProductsInput : PagedAndSortedInputDto, IShouldNormalize
{
	public string Filter { get; set; }

	public DateTime? StartDate { get; set; }

	public DateTime? EndDate { get; set; }

	   public int? CategoryId {get;set;}
	  public decimal? Weight {get;set;}
	public decimal? Volume {get;set;}
	 public int? SupplierId {get;set;}
	



	public void Normalize()
	{
		if (Sorting.IsNullOrWhiteSpace())
		{
			Sorting = "CreationTime DESC";
		}
	}
}
public class ProductListDto : AuditedEntityDto<int> {
  public string Code {get;set;}
  public string Name {get;set;}
  public string Description {get;set;}
  public int? CategoryId {get;set;}
  public string Barcode {get;set;}
  public string Unit {get;set;}
  public decimal Weight {get;set;}
  public decimal Volume {get;set;}
  public bool IsActive {get;set;}
  public int? SupplierId {get;set;}
  public string Image {get;set;}

  public ProductListDto()
  {
  }
}
  public class FileOutputDto
  {
    public string FileName { get; set; }
    public string FileUrl { get; set; }
    public string ContentType { get; set; }

    public FileOutputDto(string fileName, string fileUrl, string contentType)
    {
      FileName = fileName;
      FileUrl = fileUrl;
      ContentType = contentType;
    }

    public FileOutputDto(string fileName)
    {
      FileName = fileName;
    }

    public FileOutputDto(string fileName, string contentType)
    {
      FileName = Path.GetFileName(fileName);
      ContentType = contentType;
      //FileUrl = fileUrl;
    }
  }

  public class FileDownloadDto(string fileName, string contentType, byte[] bytes) : FileOutputDto(fileName, contentType)
  {
    public byte[] Bytes { get; set; } = bytes;
  }
}
