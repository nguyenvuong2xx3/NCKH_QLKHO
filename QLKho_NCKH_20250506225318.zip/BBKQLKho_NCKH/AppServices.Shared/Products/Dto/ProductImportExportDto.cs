﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.Products.Dto {

public class ProductImportDto {
   public string Id {get;set;}
   public string Code {get;set;}
   public string Name {get;set;}
   public string Description {get;set;}
   public string CategoryId {get;set;}
   public string Barcode {get;set;}
   public string Unit {get;set;}
   public string Weight {get;set;}
   public string Volume {get;set;}
   public string IsActive {get;set;}
   public string SupplierId {get;set;}
   public string Image {get;set;}

}

public class GetProductsExportOptionsInput : GetProductsInput
{
	public int ExportFileType { get; set; } // 1 excel, 2, csv, 3, json
	public bool IsDisplayCode { get; set; }
	public bool IsDisplayName { get; set; }
	public bool IsDisplayDescription { get; set; }
	public bool IsDisplayCategoryId { get; set; }
	public bool IsDisplayBarcode { get; set; }
	public bool IsDisplayUnit { get; set; }
	public bool IsDisplayWeight { get; set; }
	public bool IsDisplayVolume { get; set; }
	public bool IsDisplayIsActive { get; set; }
	public bool IsDisplaySupplierId { get; set; }
	public bool IsDisplayImage { get; set; }

}
}
