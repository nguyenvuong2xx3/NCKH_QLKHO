﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using System;
using QLKho_NCKH.QLKho_NCKH.Dto;
using QLKho_NCKH.Products.Dto;
using System.Threading.Tasks;
using System.IO;

namespace QLKho_NCKH.Products
{

public interface IProductAppService : IApplicationService
{
	Task<ProductEditDto> CreateProduct(ProductCreatingInput input);

	Task<ProductEditDto> GetProduct(int id);

	Task<ProductEditDto> EditProduct(ProductEditDto input);

	Task<PagedResultDto<ProductListDto>> GetProducts(GetProductsInput input);

	Task DeleteProduct(int Id);



		}
	}
