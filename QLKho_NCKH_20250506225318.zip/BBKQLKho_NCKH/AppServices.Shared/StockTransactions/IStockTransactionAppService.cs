﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Dependency;
using System;
using QLKho_NCKH.QLKho_NCKH.Dto;
using QLKho_NCKH.StockTransactions.Dto;
using System.Threading.Tasks;
using System.IO;

namespace QLKho_NCKH.StockTransactions
{

public interface IStockTransactionAppService : IApplicationService
{
	Task<StockTransactionEditDto> CreateStockTransaction(StockTransactionCreatingInput input);

	Task<StockTransactionEditDto> GetStockTransaction(int id);

	Task<StockTransactionEditDto> EditStockTransaction(StockTransactionEditDto input);

	Task<PagedResultDto<StockTransactionListDto>> GetStockTransactions(GetStockTransactionsInput input);

	Task DeleteStockTransaction(int Id);



		}
	}
