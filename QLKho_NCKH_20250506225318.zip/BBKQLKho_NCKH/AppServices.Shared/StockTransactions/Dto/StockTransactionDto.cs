﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using BBK.SaaS.Dto;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.StockTransactions.Dto {

public class StockTransactionCreatingInput {
   public string TransactionCode {get;set;}
   public int TransactionType {get;set;}
   public DateTime TransactionDate {get;set;}
   public int? FromWarehouseId {get;set;}
   public int? ToWarehouseId {get;set;}
   public int? SupplierId {get;set;}
   public string ReferenceNumber {get;set;}
   public string Note {get;set;}
   public int Status {get;set;}

}

public class StockTransactionEditDto: EntityDto<int> {
   public string TransactionCode {get;set;}
   public int TransactionType {get;set;}
   public DateTime TransactionDate {get;set;}
   public int? FromWarehouseId {get;set;}
   public int? ToWarehouseId {get;set;}
   public int? SupplierId {get;set;}
   public string ReferenceNumber {get;set;}
   public string Note {get;set;}
   public int Status {get;set;}

}

public class GetStockTransactionsInput : PagedAndSortedInputDto, IShouldNormalize
{
	public string Filter { get; set; }

	public DateTime? StartDate { get; set; }

	public DateTime? EndDate { get; set; }

	 public int? TransactionType {get;set;}
	 public int? FromWarehouseId {get;set;}
	public int? ToWarehouseId {get;set;}
	public int? SupplierId {get;set;}
	  public int? Status {get;set;}




	public void Normalize()
	{
		if (Sorting.IsNullOrWhiteSpace())
		{
			Sorting = "CreationTime DESC";
		}
	}
}
public class StockTransactionListDto : AuditedEntityDto<int> {
  public string TransactionCode {get;set;}
  public int TransactionType {get;set;}
  public DateTime TransactionDate {get;set;}
  public int? FromWarehouseId {get;set;}
  public int? ToWarehouseId {get;set;}
  public int? SupplierId {get;set;}
  public string ReferenceNumber {get;set;}
  public string Note {get;set;}
  public int Status {get;set;}

  public StockTransactionListDto()
  {
  }
}
  public class FileOutputDto
  {
    public string FileName { get; set; }
    public string FileUrl { get; set; }
    public string ContentType { get; set; }

    public FileOutputDto(string fileName, string fileUrl, string contentType)
    {
      FileName = fileName;
      FileUrl = fileUrl;
      ContentType = contentType;
    }

    public FileOutputDto(string fileName)
    {
      FileName = fileName;
    }

    public FileOutputDto(string fileName, string contentType)
    {
      FileName = Path.GetFileName(fileName);
      ContentType = contentType;
      //FileUrl = fileUrl;
    }
  }

  public class FileDownloadDto(string fileName, string contentType, byte[] bytes) : FileOutputDto(fileName, contentType)
  {
    public byte[] Bytes { get; set; } = bytes;
  }
}
