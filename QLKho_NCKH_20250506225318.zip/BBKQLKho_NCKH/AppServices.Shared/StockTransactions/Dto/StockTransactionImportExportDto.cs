﻿using System;
using Abp.Application.Services.Dto;
using Abp.Extensions;
using Abp.Runtime.Validation;
using System.IO;
using QLKho_NCKH.QLKho_NCKH.Dto;

namespace QLKho_NCKH.StockTransactions.Dto {

public class StockTransactionImportDto {
   public string Id {get;set;}
   public string TransactionCode {get;set;}
   public string TransactionType {get;set;}
   public string TransactionDate {get;set;}
   public string FromWarehouseId {get;set;}
   public string ToWarehouseId {get;set;}
   public string SupplierId {get;set;}
   public string ReferenceNumber {get;set;}
   public string Note {get;set;}
   public string Status {get;set;}

}

public class GetStockTransactionsExportOptionsInput : GetStockTransactionsInput
{
	public int ExportFileType { get; set; } // 1 excel, 2, csv, 3, json
	public bool IsDisplayTransactionCode { get; set; }
	public bool IsDisplayTransactionType { get; set; }
	public bool IsDisplayTransactionDate { get; set; }
	public bool IsDisplayFromWarehouseId { get; set; }
	public bool IsDisplayToWarehouseId { get; set; }
	public bool IsDisplaySupplierId { get; set; }
	public bool IsDisplayReferenceNumber { get; set; }
	public bool IsDisplayNote { get; set; }
	public bool IsDisplayStatus { get; set; }

}
}
