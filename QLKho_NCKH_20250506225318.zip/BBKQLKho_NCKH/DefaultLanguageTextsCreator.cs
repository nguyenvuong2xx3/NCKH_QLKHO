﻿private static IEnumerable<ApplicationLanguageText> GetInitialCMSLanguageTexts()
{
    List<ApplicationLanguageText> viTexts = new List<ApplicationLanguageText>
    {
        // Table: Category
        new() { Key = "Name", Value = "Name", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Description", Value = "Description", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ParentId", Value = "ParentId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: InventoryItem
        new() { Key = "ProductId", Value = "ProductId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "StorageLocationId", Value = "StorageLocationId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Quantity", Value = "Quantity", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ReservedQuantity", Value = "ReservedQuantity", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "UnitPrice", Value = "UnitPrice", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: Product
        new() { Key = "Code", Value = "Code", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "CategoryId", Value = "CategoryId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Barcode", Value = "Barcode", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Unit", Value = "Unit", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Weight", Value = "Weight", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Volume", Value = "Volume", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "IsActive", Value = "IsActive", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "SupplierId", Value = "SupplierId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Image", Value = "Image", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: StockTransactionDetail
        new() { Key = "StockTransactionId", Value = "StockTransactionId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Note", Value = "Note", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "BatchNumber", Value = "BatchNumber", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ExpiryDate", Value = "ExpiryDate", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: StockTransaction
        new() { Key = "TransactionCode", Value = "TransactionCode", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "TransactionType", Value = "TransactionType", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "TransactionDate", Value = "TransactionDate", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "FromWarehouseId", Value = "FromWarehouseId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ToWarehouseId", Value = "ToWarehouseId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ReferenceNumber", Value = "ReferenceNumber", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Status", Value = "Status", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: StorageLocation
        new() { Key = "WarehouseId", Value = "WarehouseId", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Capacity", Value = "Capacity", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "CurrentVolume", Value = "CurrentVolume", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "IsAvailable", Value = "IsAvailable", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: Supplier
        new() { Key = "Address", Value = "Address", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "PhoneNumber", Value = "PhoneNumber", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Email", Value = "Email", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "TaxCode", Value = "TaxCode", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: Warehous
        new() { Key = "Location", Value = "Location", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "TotalArea", Value = "TotalArea", LanguageName = "vi", Source = "QLKho_NCKH", CreationTime = DateTime.Now },

    };
    List<ApplicationLanguageText> enTexts = new List<ApplicationLanguageText>
    {
        // Table: Category
        new() { Key = "Name", Value = "Name", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Description", Value = "Description", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ParentId", Value = "ParentId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: InventoryItem
        new() { Key = "ProductId", Value = "ProductId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "StorageLocationId", Value = "StorageLocationId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Quantity", Value = "Quantity", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ReservedQuantity", Value = "ReservedQuantity", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "UnitPrice", Value = "UnitPrice", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: Product
        new() { Key = "Code", Value = "Code", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "CategoryId", Value = "CategoryId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Barcode", Value = "Barcode", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Unit", Value = "Unit", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Weight", Value = "Weight", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Volume", Value = "Volume", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "IsActive", Value = "IsActive", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "SupplierId", Value = "SupplierId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Image", Value = "Image", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: StockTransactionDetail
        new() { Key = "StockTransactionId", Value = "StockTransactionId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Note", Value = "Note", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "BatchNumber", Value = "BatchNumber", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ExpiryDate", Value = "ExpiryDate", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: StockTransaction
        new() { Key = "TransactionCode", Value = "TransactionCode", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "TransactionType", Value = "TransactionType", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "TransactionDate", Value = "TransactionDate", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "FromWarehouseId", Value = "FromWarehouseId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ToWarehouseId", Value = "ToWarehouseId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "ReferenceNumber", Value = "ReferenceNumber", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Status", Value = "Status", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: StorageLocation
        new() { Key = "WarehouseId", Value = "WarehouseId", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Capacity", Value = "Capacity", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "CurrentVolume", Value = "CurrentVolume", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "IsAvailable", Value = "IsAvailable", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: Supplier
        new() { Key = "Address", Value = "Address", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "PhoneNumber", Value = "PhoneNumber", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "Email", Value = "Email", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "TaxCode", Value = "TaxCode", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        // Table: Warehous
        new() { Key = "Location", Value = "Location", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },
        new() { Key = "TotalArea", Value = "TotalArea", LanguageName = "en", Source = "QLKho_NCKH", CreationTime = DateTime.Now },

    };
    return viTexts.Union(enTexts.AsEnumerable());
}
