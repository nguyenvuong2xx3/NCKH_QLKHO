﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using QLKho_NCKH.Entities;
using BBK.SaaS.Mdls.Categories;
using BBK.SaaS.Mdls.Categories.Dto;
using BBK.SaaS.Mdls.Categories.Entites;
using QLKho_NCKH.StockTransactions.Dto;
using Abp.Extensions;
using Abp.Linq.Extensions;
using BBK.SaaS.BlobStoring;
using BBK.SaaS.Storage;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using BBK.SaaS.Dto;
using System.IO;
using MiniExcelLibs;
using BBK.SaaS.Mdls.Categories.Geographies;
using Abp.Domain.Uow;
using BBK.SaaS;

namespace QLKho_NCKH.StockTransactions;


public interface IStockTransactionExporterAppService : IApplicationService
{
	Task<string> CheckErrorCreateDetail(StockTransactionImportDto input);
	Task<string> CheckErrorUpdateDetail(StockTransactionImportDto input);
}

public class StockTransactionExporterAppService : SaaSAppServiceBase, IStockTransactionExporterAppService
{
	private readonly IRepository<StockTransaction, long> _stockTransactionRepository;
	//private readonly IBlobContainer _avatarContainer;
	private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly IRepository<GeoUnit, long> _geoUnitRepository;
 private readonly IRepository<CategoryUnit, long> _categoryUnitRepository;

	public StockTransactionExporterAppService(IRepository<StockTransaction, long> stockTransactionRepository
		, IBlobContainerFactory blobContainerFactory
		, ITempFileCacheManager tempFileCacheManager,IRepository<GeoUnit, long> geoUnitRepository,
IRepository<CategoryUnit, long> categoryUnitRepository)
	{
		_stockTransactionRepository = stockTransactionRepository;
	_tempFileCacheManager = tempFileCacheManager;
 //_avatarContainer = blobContainerFactory.Create("");
 _geoUnitRepository = geoUnitRepository;
 _categoryUnitRepository = categoryUnitRepository;
	}

	public async Task<FileDto> ExportData(GetStockTransactionsExportOptionsInput input)
	{
using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
{
		var stockTransactionQuery = _stockTransactionRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.TransactionCode.Contains(input.Filter) ||u.ReferenceNumber.Contains(input.Filter) ||u.Note.Contains(input.Filter))

				.WhereIf(input.StartDate.HasValue, t => t.CreationTime >= input.StartDate.Value)
				.WhereIf(input.EndDate.HasValue, t => t.CreationTime <= input.EndDate.Value);

		var stockTransaction = await stockTransactionQuery.OrderBy(s => s.CreationTime).ThenBy(s => s.LastModificationTime ?? DateTime.MinValue).ToListAsync();

   var stockTransactionListDtos = new List<StockTransactionListDto>();
foreach (var s in stockTransaction)
{



stockTransactionListDtos.Add(new StockTransactionListDto
{
Id  = s. Id,
TransactionCode  = s. TransactionCode,
TransactionType  = s. TransactionType,
TransactionDate  = s. TransactionDate,
FromWarehouseId  = s. FromWarehouseId,
ToWarehouseId  = s. ToWarehouseId,
SupplierId  = s. SupplierId,
ReferenceNumber  = s. ReferenceNumber,
Note  = s. Note,
Status  = s. Status,

//TenDiaChi = address,
//AvatarPath = avatarBase64,
});
}


if (input.ExportFileType == 0)
{
	return await ExportExcel( stockTransactionListDtos);
}
else if (input.ExportFileType == 1)
{
		return await ExportExcelOptions( stockTransactionListDtos, input);
}
//else if (input.ExportFileType == 2)
//{
//	return await ExportCsv( stockTransactionListDtos);
//}
else if (input.ExportFileType == 3)
{
	return await ExportJson( stockTransactionListDtos);
}
else
{
	throw new UserFriendlyException("Không hỗ trợ định dạng xuất file này");
}
	}

}

private async Task<FileDto> ExportJson(List<StockTransactionListDto> StockTransactionList)
{
var fileDto = new FileDto()
{
FileName = "Dữ liệu StockTransaction.json",
FileType = "application/json",
FileToken = Guid.NewGuid().ToString()
};

var jsonData = System.Text.Json.JsonSerializer.Serialize(StockTransactionList, new System.Text.Json.JsonSerializerOptions
{
WriteIndented = true
});

byte[] fileContent = Encoding.UTF8.GetBytes(jsonData);

_tempFileCacheManager.SetFile(fileDto.FileToken, fileContent);

return fileDto;
}


	private async Task<FileDto> ExportExcel(List<StockTransactionListDto> StockTransactionList)
{

  var allCategorieParents = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == null).ToListAsync();

  var country = await _geoUnitRepository.GetAll().Where(x => x.KeyName == "vi").ToListAsync();
  var allProvinces = await _geoUnitRepository.GetAll().Where(x => x.ParentId == country.FirstOrDefault().Id).OrderBy(x => x.OrderIndex).ToListAsync();

  var fileDto = new FileDto()
  {
    FileName = "Dữ liệu StockTransaction.xlsx",
    FileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    FileToken = Guid.NewGuid().ToString()
  };

  var excelData = new List<Dictionary<string, object>>();

  foreach (var s in StockTransactionList)
  {
  			var row = new Dictionary<string, object>
  {
   { "TransactionCode", s.TransactionCode},
   { "TransactionType", s.TransactionType},
   { "TransactionDate", s.TransactionDate},
   { "FromWarehouseId", s.FromWarehouseId},
   { "ToWarehouseId", s.ToWarehouseId},
   { "SupplierId", s.SupplierId},
   { "ReferenceNumber", s.ReferenceNumber},
   { "Note", s.Note},
   { "Status", s.Status},

  };

    excelData.Add(row);
  }

  var categoriesData = new List<Dictionary<string, object>>();
  foreach (var categorieParent in allCategorieParents)
  {
    if (categorieParent != null) // Đảm bảo rằng Id không phải null
    {
      var row = new Dictionary<string, object>
        {
          { "Mã nhập", categorieParent.Id },
          { "Danh mục hiển thị", categorieParent.DisplayName ?? "" },
          { "Loại danh mục", "" },
          { "Ghi chú", "" }
        };
      categoriesData.Add(row);
    }

    var allcategorieChilds = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == categorieParent.Id).ToListAsync();
    if (allcategorieChilds != null)
    {
      foreach (var categorieChild in allcategorieChilds)
      {
        if (categorieChild != null) // Đảm bảo rằng Id không phải null
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", categorieChild.Id },
            { "Danh mục hiển thị", categorieChild.DisplayName },
            { "Loại danh mục", categorieParent.DisplayName },
            { "Ghi chú", "Lưu ý: chỉ cần nhập id của danh mục" }
          };
          categoriesData.Add(row);
        }
      }
    }
  }


  var geossData = new List<Dictionary<string, object>>();
  foreach (var province in allProvinces)
  {
    if (province != null)
    {
      var row = new Dictionary<string, object>
      {
        { "Mã nhập", province.Id },
        { "Code", province.Code },
        { "Hiển thị", province.DisplayName ?? "" },
        { "Tỉnh/Thành phố", "x" },
        { "Quận/Huyện", "" },
        { "Xã/Phường", "" },
        { "Ghi chú", "" }
      };
      geossData.Add(row);
    }

    var allDistricts = await _geoUnitRepository.GetAll().Where(x => x.ParentId == province.Id).ToListAsync();
    if (allDistricts != null)
    {
      foreach (var district in allDistricts)
      {
        if (district != null)
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", district.Id },
            { "Code", district.Code },
            { "Hiển thị", district.DisplayName ?? "" },
            { "Tỉnh/Thành phố", "" },
            { "Quận/Huyện", "x" },
            { "Xã/Phường", "" },
            { "Ghi chú", "" }
          };
          geossData.Add(row);
        }

        var allWards = await _geoUnitRepository.GetAll().Where(x => x.ParentId == district.Id).ToListAsync();

        if (allWards != null)
        {
          foreach (var ward in allWards)
          {
            if (ward != null)
            {
              var row = new Dictionary<string, object>
              {
                { "Mã nhập", ward.Id },
                { "Code", ward.Code },
                { "Hiển thị", ward.DisplayName ?? "" },
                { "Tỉnh/Thành phố", "" },
                { "Quận/Huyện", "" },
                { "Xã/Phường", "x" },
                { "Ghi chú", "Lưu ý: chỉ cần nhập id của xã/phường" }
              };
              geossData.Add(row);
            }
          }

        }

      }
    }
  }

  using (var memoryStream = new MemoryStream())
  {
    memoryStream.SaveAs(new Dictionary<string, object>
    {
        { " StockTransactionDs", excelData },
        { "Danh mục", categoriesData },
        { "Địa chỉ", geossData }
    });

    _tempFileCacheManager.SetFile(fileDto.FileToken, memoryStream.ToArray());
  }

  return fileDto;
}

 private async Task<FileDto> ExportExcelOptions(List<StockTransactionListDto> StockTransactionList, GetStockTransactionsExportOptionsInput input)
{

  var allCategorieParents = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == null).ToListAsync();

  var country = await _geoUnitRepository.GetAll().Where(x => x.KeyName == "vi").ToListAsync();
  var allProvinces = await _geoUnitRepository.GetAll().Where(x => x.ParentId == country.FirstOrDefault().Id).OrderBy(x => x.OrderIndex).ToListAsync();

  var fileDto = new FileDto()
  {
    FileName = "Dữ liệu StockTransaction.xlsx",
    FileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    FileToken = Guid.NewGuid().ToString()
  };

  var excelData = new List<Dictionary<string, object>>();

  foreach (var s in StockTransactionList)
  {
			var row = new Dictionary<string, object>();
    row[L("Id")] = s.Id;
   if (input.IsDisplayTransactionCode ) row[L("TransactionCode")] = s.TransactionCode;
   if (input.IsDisplayTransactionType ) row[L("TransactionType")] = s.TransactionType;
   if (input.IsDisplayTransactionDate ) row[L("TransactionDate")] = s.TransactionDate;
   if (input.IsDisplayFromWarehouseId ) row[L("FromWarehouseId")] = s.FromWarehouseId;
   if (input.IsDisplayToWarehouseId ) row[L("ToWarehouseId")] = s.ToWarehouseId;
   if (input.IsDisplaySupplierId ) row[L("SupplierId")] = s.SupplierId;
   if (input.IsDisplayReferenceNumber ) row[L("ReferenceNumber")] = s.ReferenceNumber;
   if (input.IsDisplayNote ) row[L("Note")] = s.Note;
   if (input.IsDisplayStatus ) row[L("Status")] = s.Status;


    excelData.Add(row);
  }

  var categoriesData = new List<Dictionary<string, object>>();
  foreach (var categorieParent in allCategorieParents)
  {
    if (categorieParent != null) // Đảm bảo rằng Id không phải null
    {
      var row = new Dictionary<string, object>
        {
          { "Mã nhập", categorieParent.Id },
          { "Danh mục hiển thị", categorieParent.DisplayName ?? "" },
          { "Loại danh mục", "" },
          { "Ghi chú", "" }
        };
      categoriesData.Add(row);
    }

    var allcategorieChilds = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == categorieParent.Id).ToListAsync();
    if (allcategorieChilds != null)
    {
      foreach (var categorieChild in allcategorieChilds)
      {
        if (categorieChild != null) // Đảm bảo rằng Id không phải null
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", categorieChild.Id },
            { "Danh mục hiển thị", categorieChild.DisplayName },
            { "Loại danh mục", categorieParent.DisplayName },
            { "Ghi chú", "Lưu ý: chỉ cần nhập id của danh mục" }
          };
          categoriesData.Add(row);
        }
      }
    }
  }


  var geossData = new List<Dictionary<string, object>>();
  foreach (var province in allProvinces)
  {
    if (province != null)
    {
      var row = new Dictionary<string, object>
      {
        { "Mã nhập", province.Id },
        { "Code", province.Code },
        { "Hiển thị", province.DisplayName ?? "" },
        { "Tỉnh/Thành phố", "x" },
        { "Quận/Huyện", "" },
        { "Xã/Phường", "" },
        { "Ghi chú", "" }
      };
      geossData.Add(row);
    }

    var allDistricts = await _geoUnitRepository.GetAll().Where(x => x.ParentId == province.Id).ToListAsync();
    if (allDistricts != null)
    {
      foreach (var district in allDistricts)
      {
        if (district != null)
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", district.Id },
            { "Code", district.Code },
            { "Hiển thị", district.DisplayName ?? "" },
            { "Tỉnh/Thành phố", "" },
            { "Quận/Huyện", "x" },
            { "Xã/Phường", "" },
            { "Ghi chú", "" }
          };
          geossData.Add(row);
        }

        var allWards = await _geoUnitRepository.GetAll().Where(x => x.ParentId == district.Id).ToListAsync();

        if (allWards != null)
        {
          foreach (var ward in allWards)
          {
            if (ward != null)
            {
              var row = new Dictionary<string, object>
              {
                { "Mã nhập", ward.Id },
                { "Code", ward.Code },
                { "Hiển thị", ward.DisplayName ?? "" },
                { "Tỉnh/Thành phố", "" },
                { "Quận/Huyện", "" },
                { "Xã/Phường", "x" },
                { "Ghi chú", "Lưu ý: chỉ cần nhập id của xã/phường" }
              };
              geossData.Add(row);
            }
          }

        }

      }
    }
  }

  using (var memoryStream = new MemoryStream())
  {
    memoryStream.SaveAs(new Dictionary<string, object>
    {
        { " StockTransactionDs", excelData },
        { "Danh mục", categoriesData },
        { "Địa chỉ", geossData }
    });

    _tempFileCacheManager.SetFile(fileDto.FileToken, memoryStream.ToArray());
  }

  return fileDto;
}

public async Task<string> CheckErrorCreateDetail(StockTransactionImportDto input)
	{
	  using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
	  {
	  var duplicateDetails = new List<string>();
	  var errorDetails = new List<string>();
	  var formats = new[] { /*"dd/MM/yyyy", */"d/M/yyyy" };
	  var culture = System.Globalization.CultureInfo.InvariantCulture;









	  // Kiểm tra TransactionType
	  if (!input.TransactionType.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.TransactionType, out var TransactionType))
	      {
	          errorDetails.Add($"TransactionType: '{input.TransactionType}' không hợp lệ");
	      }
	      else if (TransactionType <= 0)
	      {
	          errorDetails.Add($"TransactionType: '{input.TransactionType}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("TransactionType: Trường này là bắt buộc"); }

	  // Kiểm tra TransactionDate
	  if (!input.TransactionDate.IsNullOrWhiteSpace())
	  {
	      if (!DateTime.TryParse(input.TransactionDate, out var TransactionDate))
	      {
	          errorDetails.Add($"TransactionDate: '{input.TransactionDate}' không hợp lệ");
	      }
	      else if (TransactionDate.Year < 1900)
	      {
	          errorDetails.Add($"TransactionDate: '{input.TransactionDate}' không hợp lệ");
	      }
	  }
	  else { errorDetails.Add("TransactionDate: Trường này là bắt buộc"); }

	  // Kiểm tra FromWarehouseId
	  if (!input.FromWarehouseId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.FromWarehouseId, out var FromWarehouseId))
	      {
	          errorDetails.Add($"FromWarehouseId: '{input.FromWarehouseId}' không hợp lệ");
	      }
	      else if (FromWarehouseId <= 0)
	      {
	          errorDetails.Add($"FromWarehouseId: '{input.FromWarehouseId}' phải lớn hơn 0");
	      }
	  }


	  // Kiểm tra ToWarehouseId
	  if (!input.ToWarehouseId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.ToWarehouseId, out var ToWarehouseId))
	      {
	          errorDetails.Add($"ToWarehouseId: '{input.ToWarehouseId}' không hợp lệ");
	      }
	      else if (ToWarehouseId <= 0)
	      {
	          errorDetails.Add($"ToWarehouseId: '{input.ToWarehouseId}' phải lớn hơn 0");
	      }
	  }


	  // Kiểm tra SupplierId
	  if (!input.SupplierId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.SupplierId, out var SupplierId))
	      {
	          errorDetails.Add($"SupplierId: '{input.SupplierId}' không hợp lệ");
	      }
	      else if (SupplierId <= 0)
	      {
	          errorDetails.Add($"SupplierId: '{input.SupplierId}' phải lớn hơn 0");
	      }
	  }


	  // Kiểm tra Status
	  if (!input.Status.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.Status, out var Status))
	      {
	          errorDetails.Add($"Status: '{input.Status}' không hợp lệ");
	      }
	      else if (Status <= 0)
	      {
	          errorDetails.Add($"Status: '{input.Status}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("Status: Trường này là bắt buộc"); }




	  if (!duplicateDetails.Any() && !errorDetails.Any())
	  return string.Empty;

	  var duplicate = duplicateDetails.Any() ? $"Trùng dữ liệu {string.Join(", ", duplicateDetails)}" : string.Empty;
	  var error = errorDetails.Any() ? $"Lỗi dữ liệu {string.Join(", ", errorDetails)}" : string.Empty;
	  var notification = string.Join(". ", new[] { duplicate, error }.Where(s => !string.IsNullOrEmpty(s)));
	  return notification;
	  }
	  }

	  public async Task<string> CheckErrorUpdateDetail(StockTransactionImportDto input)
   {
	  using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
	  {
	  var duplicateDetails = new List<string>();
	  var errorDetails = new List<string>();
	  var formats = new[] { /*"dd/MM/yyyy", */"d/M/yyyy" };
	  var culture = System.Globalization.CultureInfo.InvariantCulture;



  if (!long.TryParse(input.Id, out var Id))
  {
    errorDetails.Add($"Id: '{input.Id}' giá trị không hợp lệ");
  }
  else
  {
    var accommodationUnit = await _stockTransactionRepository.FirstOrDefaultAsync(x => x.Id == Id);
    if (accommodationUnit != null)
    {

    }
    else if (accommodationUnit == null)
    {
       errorDetails.Add($"Id: '{input.Id}' không tồn tại");
    }
  }





	  // Kiểm tra TransactionType
	  if (!input.TransactionType.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.TransactionType, out var TransactionType))
	      {
	          errorDetails.Add($"TransactionType: '{input.TransactionType}' không hợp lệ");
	      }
	      else if (TransactionType <= 0)
	      {
	          errorDetails.Add($"TransactionType: '{input.TransactionType}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("TransactionType: Trường này là bắt buộc"); }

	  // Kiểm tra TransactionDate
	  if (!input.TransactionDate.IsNullOrWhiteSpace())
	  {
	      if (!DateTime.TryParse(input.TransactionDate, out var TransactionDate))
	      {
	          errorDetails.Add($"TransactionDate: '{input.TransactionDate}' không hợp lệ");
	      }
	      else if (TransactionDate.Year < 1900)
	      {
	          errorDetails.Add($"TransactionDate: '{input.TransactionDate}' không hợp lệ");
	      }
	  }
	  else { errorDetails.Add("TransactionDate: Trường này là bắt buộc"); }

	  // Kiểm tra FromWarehouseId
	  if (!input.FromWarehouseId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.FromWarehouseId, out var FromWarehouseId))
	      {
	          errorDetails.Add($"FromWarehouseId: '{input.FromWarehouseId}' không hợp lệ");
	      }
	      else if (FromWarehouseId <= 0)
	      {
	          errorDetails.Add($"FromWarehouseId: '{input.FromWarehouseId}' phải lớn hơn 0");
	      }
	  }


	  // Kiểm tra ToWarehouseId
	  if (!input.ToWarehouseId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.ToWarehouseId, out var ToWarehouseId))
	      {
	          errorDetails.Add($"ToWarehouseId: '{input.ToWarehouseId}' không hợp lệ");
	      }
	      else if (ToWarehouseId <= 0)
	      {
	          errorDetails.Add($"ToWarehouseId: '{input.ToWarehouseId}' phải lớn hơn 0");
	      }
	  }


	  // Kiểm tra SupplierId
	  if (!input.SupplierId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.SupplierId, out var SupplierId))
	      {
	          errorDetails.Add($"SupplierId: '{input.SupplierId}' không hợp lệ");
	      }
	      else if (SupplierId <= 0)
	      {
	          errorDetails.Add($"SupplierId: '{input.SupplierId}' phải lớn hơn 0");
	      }
	  }


	  // Kiểm tra Status
	  if (!input.Status.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.Status, out var Status))
	      {
	          errorDetails.Add($"Status: '{input.Status}' không hợp lệ");
	      }
	      else if (Status <= 0)
	      {
	          errorDetails.Add($"Status: '{input.Status}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("Status: Trường này là bắt buộc"); }



	  if (!duplicateDetails.Any() && !errorDetails.Any())
	  return string.Empty;

	  var duplicate = duplicateDetails.Any() ? $"Trùng dữ liệu {string.Join(", ", duplicateDetails)}" : string.Empty;
	  var error = errorDetails.Any() ? $"Lỗi dữ liệu {string.Join(", ", errorDetails)}" : string.Empty;
	  var notification = string.Join(". ", new[] { duplicate, error }.Where(s => !string.IsNullOrEmpty(s)));
	  return notification;
	  }
	}

}

