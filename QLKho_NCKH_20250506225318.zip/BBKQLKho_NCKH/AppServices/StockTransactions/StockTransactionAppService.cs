﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Abp.Linq.Extensions;
using BBK.SaaS;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using Abp.Extensions;
using Abp.Domain.Uow;
using QLKho_NCKH.QLKho_NCKH;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.Entities;
using QLKho_NCKH.StockTransactions.Dto;

namespace QLKho_NCKH.StockTransactions;



public class StockTransactionAppService :SaaSAppServiceBase, IStockTransactionAppService
{
 private readonly IRepository<StockTransaction, int> _stockTransactionRepository;
 private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly MediaTypeManager MediaTypeManager;

 public StockTransactionAppService(IRepository<StockTransaction, int> stockTransactionRepository
   , IBlobContainerFactory blobContainerFactory
   , ITempFileCacheManager tempFileCacheManager
   , MediaTypeManager mediaTypeManager

 )
 {
   _stockTransactionRepository = stockTransactionRepository;
   _tempFileCacheManager = tempFileCacheManager;
   MediaTypeManager = mediaTypeManager;
  }


	public async Task<StockTransactionEditDto> CreateStockTransaction(StockTransactionCreatingInput input)
	{
		StockTransaction stockTransaction = ObjectMapper.Map<StockTransaction>(input);




		await _stockTransactionRepository.InsertAsync(stockTransaction);
		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<StockTransactionEditDto>(stockTransaction);
	}

	public async Task<PagedResultDto<StockTransactionListDto>> GetStockTransactions(GetStockTransactionsInput input)
	{
		var query = _stockTransactionRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.TransactionCode.Contains(input.Filter) ||u.ReferenceNumber.Contains(input.Filter) ||u.Note.Contains(input.Filter))


			  ;

		var count = await query.CountAsync();
		var result = await query.OrderBy(input.Sorting)
				.PageBy(input)
				.ToListAsync();
		var listDto = ObjectMapper.Map<List<StockTransactionListDto>>(result);
		return new PagedResultDto<StockTransactionListDto>(
				count,
				listDto
				);
	}

	public async Task<StockTransactionEditDto> GetStockTransaction(int id)
	{
		var stockTransaction = await _stockTransactionRepository.GetAsync(id);

		return ObjectMapper.Map<StockTransactionEditDto>(stockTransaction);
	}

	public async Task<StockTransactionEditDto> EditStockTransaction(StockTransactionEditDto input)
	{
		var stockTransaction = await _stockTransactionRepository.GetAsync(input.Id);
		stockTransaction.TransactionCode = input.TransactionCode;
		stockTransaction.TransactionType = input.TransactionType;
		stockTransaction.TransactionDate = input.TransactionDate;
		stockTransaction.FromWarehouseId = input.FromWarehouseId;
		stockTransaction.ToWarehouseId = input.ToWarehouseId;
		stockTransaction.SupplierId = input.SupplierId;
		stockTransaction.ReferenceNumber = input.ReferenceNumber;
		stockTransaction.Note = input.Note;
		stockTransaction.Status = input.Status;



		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<StockTransactionEditDto>(stockTransaction);
	}

	// Permission??
	public async Task DeleteStockTransaction(int Id)
	{
		await  _stockTransactionRepository.DeleteAsync(Id);
	}


	}
	////StockTransactions AutoMapper
	//configuration.CreateMap<StockTransaction, StockTransactionEditDto>();
	//configuration.CreateMap<StockTransaction, StockTransactionListDto>();
	//configuration.CreateMap<StockTransactionCreatingInput, StockTransaction>();
