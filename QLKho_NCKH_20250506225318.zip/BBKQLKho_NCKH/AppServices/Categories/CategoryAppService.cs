﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Abp.Linq.Extensions;
using BBK.SaaS;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using Abp.Extensions;
using Abp.Domain.Uow;
using QLKho_NCKH.QLKho_NCKH;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.Entities;
using QLKho_NCKH.Categories.Dto;

namespace QLKho_NCKH.Categories;



public class CategoryAppService :SaaSAppServiceBase, ICategoryAppService
{
 private readonly IRepository<Category, int> _categoryRepository;
 private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly MediaTypeManager MediaTypeManager;

 public CategoryAppService(IRepository<Category, int> categoryRepository
   , IBlobContainerFactory blobContainerFactory
   , ITempFileCacheManager tempFileCacheManager
   , MediaTypeManager mediaTypeManager

 )
 {
   _categoryRepository = categoryRepository;
   _tempFileCacheManager = tempFileCacheManager;
   MediaTypeManager = mediaTypeManager;
  }


	public async Task<CategoryEditDto> CreateCategory(CategoryCreatingInput input)
	{
		Category category = ObjectMapper.Map<Category>(input);




		await _categoryRepository.InsertAsync(category);
		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<CategoryEditDto>(category);
	}

	public async Task<PagedResultDto<CategoryListDto>> GetCategories(GetCategoriesInput input)
	{
		var query = _categoryRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.Name.Contains(input.Filter) ||u.Description.Contains(input.Filter))


			  ;

		var count = await query.CountAsync();
		var result = await query.OrderBy(input.Sorting)
				.PageBy(input)
				.ToListAsync();
		var listDto = ObjectMapper.Map<List<CategoryListDto>>(result);
		return new PagedResultDto<CategoryListDto>(
				count,
				listDto
				);
	}

	public async Task<CategoryEditDto> GetCategory(int id)
	{
		var category = await _categoryRepository.GetAsync(id);

		return ObjectMapper.Map<CategoryEditDto>(category);
	}

	public async Task<CategoryEditDto> EditCategory(CategoryEditDto input)
	{
		var category = await _categoryRepository.GetAsync(input.Id);
		category.Name = input.Name;
		category.Description = input.Description;
		category.ParentId = input.ParentId;



		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<CategoryEditDto>(category);
	}

	// Permission??
	public async Task DeleteCategory(int Id)
	{
		await  _categoryRepository.DeleteAsync(Id);
	}


	}
	////Categorys AutoMapper
	//configuration.CreateMap<Category, CategoryEditDto>();
	//configuration.CreateMap<Category, CategoryListDto>();
	//configuration.CreateMap<CategoryCreatingInput, Category>();
