﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Abp.Linq.Extensions;
using BBK.SaaS;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using Abp.Extensions;
using Abp.Domain.Uow;
using QLKho_NCKH.QLKho_NCKH;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.Entities;
using QLKho_NCKH.Products.Dto;

namespace QLKho_NCKH.Products;



public class ProductAppService :SaaSAppServiceBase, IProductAppService
{
 private readonly IRepository<Product, int> _productRepository;
 private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly MediaTypeManager MediaTypeManager;

 public ProductAppService(IRepository<Product, int> productRepository
   , IBlobContainerFactory blobContainerFactory
   , ITempFileCacheManager tempFileCacheManager
   , MediaTypeManager mediaTypeManager

 )
 {
   _productRepository = productRepository;
   _tempFileCacheManager = tempFileCacheManager;
   MediaTypeManager = mediaTypeManager;
  }


	public async Task<ProductEditDto> CreateProduct(ProductCreatingInput input)
	{
		Product product = ObjectMapper.Map<Product>(input);




		await _productRepository.InsertAsync(product);
		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<ProductEditDto>(product);
	}

	public async Task<PagedResultDto<ProductListDto>> GetProducts(GetProductsInput input)
	{
		var query = _productRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.Code.Contains(input.Filter) ||u.Name.Contains(input.Filter) ||u.Description.Contains(input.Filter) ||u.Barcode.Contains(input.Filter) ||u.Unit.Contains(input.Filter) ||u.Image.Contains(input.Filter))


			  ;

		var count = await query.CountAsync();
		var result = await query.OrderBy(input.Sorting)
				.PageBy(input)
				.ToListAsync();
		var listDto = ObjectMapper.Map<List<ProductListDto>>(result);
		return new PagedResultDto<ProductListDto>(
				count,
				listDto
				);
	}

	public async Task<ProductEditDto> GetProduct(int id)
	{
		var product = await _productRepository.GetAsync(id);

		return ObjectMapper.Map<ProductEditDto>(product);
	}

	public async Task<ProductEditDto> EditProduct(ProductEditDto input)
	{
		var product = await _productRepository.GetAsync(input.Id);
		product.Code = input.Code;
		product.Name = input.Name;
		product.Description = input.Description;
		product.CategoryId = input.CategoryId;
		product.Barcode = input.Barcode;
		product.Unit = input.Unit;
		product.Weight = input.Weight;
		product.Volume = input.Volume;
		product.IsActive = input.IsActive;
		product.SupplierId = input.SupplierId;
		product.Image = input.Image;



		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<ProductEditDto>(product);
	}

	// Permission??
	public async Task DeleteProduct(int Id)
	{
		await  _productRepository.DeleteAsync(Id);
	}


	}
	////Products AutoMapper
	//configuration.CreateMap<Product, ProductEditDto>();
	//configuration.CreateMap<Product, ProductListDto>();
	//configuration.CreateMap<ProductCreatingInput, Product>();
