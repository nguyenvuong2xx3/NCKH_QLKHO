﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using QLKho_NCKH.Entities;
using BBK.SaaS.Mdls.Categories;
using BBK.SaaS.Mdls.Categories.Dto;
using BBK.SaaS.Mdls.Categories.Entites;
using QLKho_NCKH.InventoryItems.Dto;
using Abp.Extensions;
using Abp.Linq.Extensions;
using BBK.SaaS.BlobStoring;
using BBK.SaaS.Storage;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using BBK.SaaS.Dto;
using System.IO;
using MiniExcelLibs;
using BBK.SaaS.Mdls.Categories.Geographies;
using Abp.Domain.Uow;
using BBK.SaaS;

namespace QLKho_NCKH.InventoryItems;


public interface IInventoryItemExporterAppService : IApplicationService
{
	Task<string> CheckErrorCreateDetail(InventoryItemImportDto input);
	Task<string> CheckErrorUpdateDetail(InventoryItemImportDto input);
}

public class InventoryItemExporterAppService : SaaSAppServiceBase, IInventoryItemExporterAppService
{
	private readonly IRepository<InventoryItem, long> _inventoryItemRepository;
	//private readonly IBlobContainer _avatarContainer;
	private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly IRepository<GeoUnit, long> _geoUnitRepository;
 private readonly IRepository<CategoryUnit, long> _categoryUnitRepository;

	public InventoryItemExporterAppService(IRepository<InventoryItem, long> inventoryItemRepository
		, IBlobContainerFactory blobContainerFactory
		, ITempFileCacheManager tempFileCacheManager,IRepository<GeoUnit, long> geoUnitRepository,
IRepository<CategoryUnit, long> categoryUnitRepository)
	{
		_inventoryItemRepository = inventoryItemRepository;
	_tempFileCacheManager = tempFileCacheManager;
 //_avatarContainer = blobContainerFactory.Create("");
 _geoUnitRepository = geoUnitRepository;
 _categoryUnitRepository = categoryUnitRepository;
	}

	public async Task<FileDto> ExportData(GetInventoryItemsExportOptionsInput input)
	{
using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
{
		var inventoryItemQuery = _inventoryItemRepository.GetAll()


				.WhereIf(input.StartDate.HasValue, t => t.CreationTime >= input.StartDate.Value)
				.WhereIf(input.EndDate.HasValue, t => t.CreationTime <= input.EndDate.Value);

		var inventoryItem = await inventoryItemQuery.OrderBy(s => s.CreationTime).ThenBy(s => s.LastModificationTime ?? DateTime.MinValue).ToListAsync();

   var inventoryItemListDtos = new List<InventoryItemListDto>();
foreach (var s in inventoryItem)
{



inventoryItemListDtos.Add(new InventoryItemListDto
{
Id  = s. Id,
ProductId  = s. ProductId,
StorageLocationId  = s. StorageLocationId,
Quantity  = s. Quantity,
ReservedQuantity  = s. ReservedQuantity,
UnitPrice  = s. UnitPrice,

//TenDiaChi = address,
//AvatarPath = avatarBase64,
});
}


if (input.ExportFileType == 0)
{
	return await ExportExcel( inventoryItemListDtos);
}
else if (input.ExportFileType == 1)
{
		return await ExportExcelOptions( inventoryItemListDtos, input);
}
//else if (input.ExportFileType == 2)
//{
//	return await ExportCsv( inventoryItemListDtos);
//}
else if (input.ExportFileType == 3)
{
	return await ExportJson( inventoryItemListDtos);
}
else
{
	throw new UserFriendlyException("Không hỗ trợ định dạng xuất file này");
}
	}

}

private async Task<FileDto> ExportJson(List<InventoryItemListDto> InventoryItemList)
{
var fileDto = new FileDto()
{
FileName = "Dữ liệu InventoryItem.json",
FileType = "application/json",
FileToken = Guid.NewGuid().ToString()
};

var jsonData = System.Text.Json.JsonSerializer.Serialize(InventoryItemList, new System.Text.Json.JsonSerializerOptions
{
WriteIndented = true
});

byte[] fileContent = Encoding.UTF8.GetBytes(jsonData);

_tempFileCacheManager.SetFile(fileDto.FileToken, fileContent);

return fileDto;
}


	private async Task<FileDto> ExportExcel(List<InventoryItemListDto> InventoryItemList)
{

  var allCategorieParents = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == null).ToListAsync();

  var country = await _geoUnitRepository.GetAll().Where(x => x.KeyName == "vi").ToListAsync();
  var allProvinces = await _geoUnitRepository.GetAll().Where(x => x.ParentId == country.FirstOrDefault().Id).OrderBy(x => x.OrderIndex).ToListAsync();

  var fileDto = new FileDto()
  {
    FileName = "Dữ liệu InventoryItem.xlsx",
    FileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    FileToken = Guid.NewGuid().ToString()
  };

  var excelData = new List<Dictionary<string, object>>();

  foreach (var s in InventoryItemList)
  {
  			var row = new Dictionary<string, object>
  {
   { "ProductId", s.ProductId},
   { "StorageLocationId", s.StorageLocationId},
   { "Quantity", s.Quantity},
   { "ReservedQuantity", s.ReservedQuantity},
   { "UnitPrice", s.UnitPrice},

  };

    excelData.Add(row);
  }

  var categoriesData = new List<Dictionary<string, object>>();
  foreach (var categorieParent in allCategorieParents)
  {
    if (categorieParent != null) // Đảm bảo rằng Id không phải null
    {
      var row = new Dictionary<string, object>
        {
          { "Mã nhập", categorieParent.Id },
          { "Danh mục hiển thị", categorieParent.DisplayName ?? "" },
          { "Loại danh mục", "" },
          { "Ghi chú", "" }
        };
      categoriesData.Add(row);
    }

    var allcategorieChilds = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == categorieParent.Id).ToListAsync();
    if (allcategorieChilds != null)
    {
      foreach (var categorieChild in allcategorieChilds)
      {
        if (categorieChild != null) // Đảm bảo rằng Id không phải null
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", categorieChild.Id },
            { "Danh mục hiển thị", categorieChild.DisplayName },
            { "Loại danh mục", categorieParent.DisplayName },
            { "Ghi chú", "Lưu ý: chỉ cần nhập id của danh mục" }
          };
          categoriesData.Add(row);
        }
      }
    }
  }


  var geossData = new List<Dictionary<string, object>>();
  foreach (var province in allProvinces)
  {
    if (province != null)
    {
      var row = new Dictionary<string, object>
      {
        { "Mã nhập", province.Id },
        { "Code", province.Code },
        { "Hiển thị", province.DisplayName ?? "" },
        { "Tỉnh/Thành phố", "x" },
        { "Quận/Huyện", "" },
        { "Xã/Phường", "" },
        { "Ghi chú", "" }
      };
      geossData.Add(row);
    }

    var allDistricts = await _geoUnitRepository.GetAll().Where(x => x.ParentId == province.Id).ToListAsync();
    if (allDistricts != null)
    {
      foreach (var district in allDistricts)
      {
        if (district != null)
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", district.Id },
            { "Code", district.Code },
            { "Hiển thị", district.DisplayName ?? "" },
            { "Tỉnh/Thành phố", "" },
            { "Quận/Huyện", "x" },
            { "Xã/Phường", "" },
            { "Ghi chú", "" }
          };
          geossData.Add(row);
        }

        var allWards = await _geoUnitRepository.GetAll().Where(x => x.ParentId == district.Id).ToListAsync();

        if (allWards != null)
        {
          foreach (var ward in allWards)
          {
            if (ward != null)
            {
              var row = new Dictionary<string, object>
              {
                { "Mã nhập", ward.Id },
                { "Code", ward.Code },
                { "Hiển thị", ward.DisplayName ?? "" },
                { "Tỉnh/Thành phố", "" },
                { "Quận/Huyện", "" },
                { "Xã/Phường", "x" },
                { "Ghi chú", "Lưu ý: chỉ cần nhập id của xã/phường" }
              };
              geossData.Add(row);
            }
          }

        }

      }
    }
  }

  using (var memoryStream = new MemoryStream())
  {
    memoryStream.SaveAs(new Dictionary<string, object>
    {
        { " InventoryItemDs", excelData },
        { "Danh mục", categoriesData },
        { "Địa chỉ", geossData }
    });

    _tempFileCacheManager.SetFile(fileDto.FileToken, memoryStream.ToArray());
  }

  return fileDto;
}

 private async Task<FileDto> ExportExcelOptions(List<InventoryItemListDto> InventoryItemList, GetInventoryItemsExportOptionsInput input)
{

  var allCategorieParents = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == null).ToListAsync();

  var country = await _geoUnitRepository.GetAll().Where(x => x.KeyName == "vi").ToListAsync();
  var allProvinces = await _geoUnitRepository.GetAll().Where(x => x.ParentId == country.FirstOrDefault().Id).OrderBy(x => x.OrderIndex).ToListAsync();

  var fileDto = new FileDto()
  {
    FileName = "Dữ liệu InventoryItem.xlsx",
    FileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    FileToken = Guid.NewGuid().ToString()
  };

  var excelData = new List<Dictionary<string, object>>();

  foreach (var s in InventoryItemList)
  {
			var row = new Dictionary<string, object>();
    row[L("Id")] = s.Id;
   if (input.IsDisplayProductId ) row[L("ProductId")] = s.ProductId;
   if (input.IsDisplayStorageLocationId ) row[L("StorageLocationId")] = s.StorageLocationId;
   if (input.IsDisplayQuantity ) row[L("Quantity")] = s.Quantity;
   if (input.IsDisplayReservedQuantity ) row[L("ReservedQuantity")] = s.ReservedQuantity;
   if (input.IsDisplayUnitPrice ) row[L("UnitPrice")] = s.UnitPrice;


    excelData.Add(row);
  }

  var categoriesData = new List<Dictionary<string, object>>();
  foreach (var categorieParent in allCategorieParents)
  {
    if (categorieParent != null) // Đảm bảo rằng Id không phải null
    {
      var row = new Dictionary<string, object>
        {
          { "Mã nhập", categorieParent.Id },
          { "Danh mục hiển thị", categorieParent.DisplayName ?? "" },
          { "Loại danh mục", "" },
          { "Ghi chú", "" }
        };
      categoriesData.Add(row);
    }

    var allcategorieChilds = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == categorieParent.Id).ToListAsync();
    if (allcategorieChilds != null)
    {
      foreach (var categorieChild in allcategorieChilds)
      {
        if (categorieChild != null) // Đảm bảo rằng Id không phải null
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", categorieChild.Id },
            { "Danh mục hiển thị", categorieChild.DisplayName },
            { "Loại danh mục", categorieParent.DisplayName },
            { "Ghi chú", "Lưu ý: chỉ cần nhập id của danh mục" }
          };
          categoriesData.Add(row);
        }
      }
    }
  }


  var geossData = new List<Dictionary<string, object>>();
  foreach (var province in allProvinces)
  {
    if (province != null)
    {
      var row = new Dictionary<string, object>
      {
        { "Mã nhập", province.Id },
        { "Code", province.Code },
        { "Hiển thị", province.DisplayName ?? "" },
        { "Tỉnh/Thành phố", "x" },
        { "Quận/Huyện", "" },
        { "Xã/Phường", "" },
        { "Ghi chú", "" }
      };
      geossData.Add(row);
    }

    var allDistricts = await _geoUnitRepository.GetAll().Where(x => x.ParentId == province.Id).ToListAsync();
    if (allDistricts != null)
    {
      foreach (var district in allDistricts)
      {
        if (district != null)
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", district.Id },
            { "Code", district.Code },
            { "Hiển thị", district.DisplayName ?? "" },
            { "Tỉnh/Thành phố", "" },
            { "Quận/Huyện", "x" },
            { "Xã/Phường", "" },
            { "Ghi chú", "" }
          };
          geossData.Add(row);
        }

        var allWards = await _geoUnitRepository.GetAll().Where(x => x.ParentId == district.Id).ToListAsync();

        if (allWards != null)
        {
          foreach (var ward in allWards)
          {
            if (ward != null)
            {
              var row = new Dictionary<string, object>
              {
                { "Mã nhập", ward.Id },
                { "Code", ward.Code },
                { "Hiển thị", ward.DisplayName ?? "" },
                { "Tỉnh/Thành phố", "" },
                { "Quận/Huyện", "" },
                { "Xã/Phường", "x" },
                { "Ghi chú", "Lưu ý: chỉ cần nhập id của xã/phường" }
              };
              geossData.Add(row);
            }
          }

        }

      }
    }
  }

  using (var memoryStream = new MemoryStream())
  {
    memoryStream.SaveAs(new Dictionary<string, object>
    {
        { " InventoryItemDs", excelData },
        { "Danh mục", categoriesData },
        { "Địa chỉ", geossData }
    });

    _tempFileCacheManager.SetFile(fileDto.FileToken, memoryStream.ToArray());
  }

  return fileDto;
}

public async Task<string> CheckErrorCreateDetail(InventoryItemImportDto input)
	{
	  using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
	  {
	  var duplicateDetails = new List<string>();
	  var errorDetails = new List<string>();
	  var formats = new[] { /*"dd/MM/yyyy", */"d/M/yyyy" };
	  var culture = System.Globalization.CultureInfo.InvariantCulture;









	  // Kiểm tra ProductId
	  if (!input.ProductId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.ProductId, out var ProductId))
	      {
	          errorDetails.Add($"ProductId: '{input.ProductId}' không hợp lệ");
	      }
	      else if (ProductId <= 0)
	      {
	          errorDetails.Add($"ProductId: '{input.ProductId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("ProductId: Trường này là bắt buộc"); }

	  // Kiểm tra StorageLocationId
	  if (!input.StorageLocationId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.StorageLocationId, out var StorageLocationId))
	      {
	          errorDetails.Add($"StorageLocationId: '{input.StorageLocationId}' không hợp lệ");
	      }
	      else if (StorageLocationId <= 0)
	      {
	          errorDetails.Add($"StorageLocationId: '{input.StorageLocationId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("StorageLocationId: Trường này là bắt buộc"); }

	  // Kiểm tra Quantity
	  if (!input.Quantity.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.Quantity, out var Quantity))
	      {
	          errorDetails.Add($"Quantity: '{input.Quantity}' không hợp lệ");
	      }
	      else if (Quantity <= 0)
	      {
	          errorDetails.Add($"Quantity: '{input.Quantity}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("Quantity: Trường này là bắt buộc"); }

	  // Kiểm tra ReservedQuantity
	  if (!input.ReservedQuantity.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.ReservedQuantity, out var ReservedQuantity))
	      {
	          errorDetails.Add($"ReservedQuantity: '{input.ReservedQuantity}' không hợp lệ");
	      }
	      else if (ReservedQuantity <= 0)
	      {
	          errorDetails.Add($"ReservedQuantity: '{input.ReservedQuantity}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("ReservedQuantity: Trường này là bắt buộc"); }

	  // Kiểm tra UnitPrice
	  if (!input.UnitPrice.IsNullOrWhiteSpace())
	  {
	      if (!decimal.TryParse(input.UnitPrice, out var UnitPrice))
	      {
	          errorDetails.Add($"UnitPrice: '{input.UnitPrice}' không hợp lệ");
	      }
	      else if (UnitPrice <= 0)
	      {
	          errorDetails.Add($"UnitPrice: '{input.UnitPrice}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("UnitPrice: Trường này là bắt buộc"); }




	  if (!duplicateDetails.Any() && !errorDetails.Any())
	  return string.Empty;

	  var duplicate = duplicateDetails.Any() ? $"Trùng dữ liệu {string.Join(", ", duplicateDetails)}" : string.Empty;
	  var error = errorDetails.Any() ? $"Lỗi dữ liệu {string.Join(", ", errorDetails)}" : string.Empty;
	  var notification = string.Join(". ", new[] { duplicate, error }.Where(s => !string.IsNullOrEmpty(s)));
	  return notification;
	  }
	  }

	  public async Task<string> CheckErrorUpdateDetail(InventoryItemImportDto input)
   {
	  using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
	  {
	  var duplicateDetails = new List<string>();
	  var errorDetails = new List<string>();
	  var formats = new[] { /*"dd/MM/yyyy", */"d/M/yyyy" };
	  var culture = System.Globalization.CultureInfo.InvariantCulture;



  if (!long.TryParse(input.Id, out var Id))
  {
    errorDetails.Add($"Id: '{input.Id}' giá trị không hợp lệ");
  }
  else
  {
    var accommodationUnit = await _inventoryItemRepository.FirstOrDefaultAsync(x => x.Id == Id);
    if (accommodationUnit != null)
    {

    }
    else if (accommodationUnit == null)
    {
       errorDetails.Add($"Id: '{input.Id}' không tồn tại");
    }
  }





	  // Kiểm tra ProductId
	  if (!input.ProductId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.ProductId, out var ProductId))
	      {
	          errorDetails.Add($"ProductId: '{input.ProductId}' không hợp lệ");
	      }
	      else if (ProductId <= 0)
	      {
	          errorDetails.Add($"ProductId: '{input.ProductId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("ProductId: Trường này là bắt buộc"); }

	  // Kiểm tra StorageLocationId
	  if (!input.StorageLocationId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.StorageLocationId, out var StorageLocationId))
	      {
	          errorDetails.Add($"StorageLocationId: '{input.StorageLocationId}' không hợp lệ");
	      }
	      else if (StorageLocationId <= 0)
	      {
	          errorDetails.Add($"StorageLocationId: '{input.StorageLocationId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("StorageLocationId: Trường này là bắt buộc"); }

	  // Kiểm tra Quantity
	  if (!input.Quantity.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.Quantity, out var Quantity))
	      {
	          errorDetails.Add($"Quantity: '{input.Quantity}' không hợp lệ");
	      }
	      else if (Quantity <= 0)
	      {
	          errorDetails.Add($"Quantity: '{input.Quantity}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("Quantity: Trường này là bắt buộc"); }

	  // Kiểm tra ReservedQuantity
	  if (!input.ReservedQuantity.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.ReservedQuantity, out var ReservedQuantity))
	      {
	          errorDetails.Add($"ReservedQuantity: '{input.ReservedQuantity}' không hợp lệ");
	      }
	      else if (ReservedQuantity <= 0)
	      {
	          errorDetails.Add($"ReservedQuantity: '{input.ReservedQuantity}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("ReservedQuantity: Trường này là bắt buộc"); }

	  // Kiểm tra UnitPrice
	  if (!input.UnitPrice.IsNullOrWhiteSpace())
	  {
	      if (!decimal.TryParse(input.UnitPrice, out var UnitPrice))
	      {
	          errorDetails.Add($"UnitPrice: '{input.UnitPrice}' không hợp lệ");
	      }
	      else if (UnitPrice <= 0)
	      {
	          errorDetails.Add($"UnitPrice: '{input.UnitPrice}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("UnitPrice: Trường này là bắt buộc"); }



	  if (!duplicateDetails.Any() && !errorDetails.Any())
	  return string.Empty;

	  var duplicate = duplicateDetails.Any() ? $"Trùng dữ liệu {string.Join(", ", duplicateDetails)}" : string.Empty;
	  var error = errorDetails.Any() ? $"Lỗi dữ liệu {string.Join(", ", errorDetails)}" : string.Empty;
	  var notification = string.Join(". ", new[] { duplicate, error }.Where(s => !string.IsNullOrEmpty(s)));
	  return notification;
	  }
	}

}

