﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Abp.Linq.Extensions;
using BBK.SaaS;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using Abp.Extensions;
using Abp.Domain.Uow;
using QLKho_NCKH.QLKho_NCKH;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.Entities;
using QLKho_NCKH.StorageLocations.Dto;

namespace QLKho_NCKH.StorageLocations;



public class StorageLocationAppService :SaaSAppServiceBase, IStorageLocationAppService
{
 private readonly IRepository<StorageLocation, int> _storageLocationRepository;
 private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly MediaTypeManager MediaTypeManager;

 public StorageLocationAppService(IRepository<StorageLocation, int> storageLocationRepository
   , IBlobContainerFactory blobContainerFactory
   , ITempFileCacheManager tempFileCacheManager
   , MediaTypeManager mediaTypeManager

 )
 {
   _storageLocationRepository = storageLocationRepository;
   _tempFileCacheManager = tempFileCacheManager;
   MediaTypeManager = mediaTypeManager;
  }


	public async Task<StorageLocationEditDto> CreateStorageLocation(StorageLocationCreatingInput input)
	{
		StorageLocation storageLocation = ObjectMapper.Map<StorageLocation>(input);




		await _storageLocationRepository.InsertAsync(storageLocation);
		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<StorageLocationEditDto>(storageLocation);
	}

	public async Task<PagedResultDto<StorageLocationListDto>> GetStorageLocations(GetStorageLocationsInput input)
	{
		var query = _storageLocationRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.Code.Contains(input.Filter))


			  ;

		var count = await query.CountAsync();
		var result = await query.OrderBy(input.Sorting)
				.PageBy(input)
				.ToListAsync();
		var listDto = ObjectMapper.Map<List<StorageLocationListDto>>(result);
		return new PagedResultDto<StorageLocationListDto>(
				count,
				listDto
				);
	}

	public async Task<StorageLocationEditDto> GetStorageLocation(int id)
	{
		var storageLocation = await _storageLocationRepository.GetAsync(id);

		return ObjectMapper.Map<StorageLocationEditDto>(storageLocation);
	}

	public async Task<StorageLocationEditDto> EditStorageLocation(StorageLocationEditDto input)
	{
		var storageLocation = await _storageLocationRepository.GetAsync(input.Id);
		storageLocation.Code = input.Code;
		storageLocation.WarehouseId = input.WarehouseId;
		storageLocation.Capacity = input.Capacity;
		storageLocation.CurrentVolume = input.CurrentVolume;
		storageLocation.IsAvailable = input.IsAvailable;



		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<StorageLocationEditDto>(storageLocation);
	}

	// Permission??
	public async Task DeleteStorageLocation(int Id)
	{
		await  _storageLocationRepository.DeleteAsync(Id);
	}


	}
	////StorageLocations AutoMapper
	//configuration.CreateMap<StorageLocation, StorageLocationEditDto>();
	//configuration.CreateMap<StorageLocation, StorageLocationListDto>();
	//configuration.CreateMap<StorageLocationCreatingInput, StorageLocation>();
