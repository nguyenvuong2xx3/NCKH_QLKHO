﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Abp.Linq.Extensions;
using BBK.SaaS;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using Abp.Extensions;
using Abp.Domain.Uow;
using QLKho_NCKH.QLKho_NCKH;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.Entities;
using QLKho_NCKH.Suppliers.Dto;

namespace QLKho_NCKH.Suppliers;



public class SupplierAppService :SaaSAppServiceBase, ISupplierAppService
{
 private readonly IRepository<Supplier, int> _supplierRepository;
 private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly MediaTypeManager MediaTypeManager;

 public SupplierAppService(IRepository<Supplier, int> supplierRepository
   , IBlobContainerFactory blobContainerFactory
   , ITempFileCacheManager tempFileCacheManager
   , MediaTypeManager mediaTypeManager

 )
 {
   _supplierRepository = supplierRepository;
   _tempFileCacheManager = tempFileCacheManager;
   MediaTypeManager = mediaTypeManager;
  }


	public async Task<SupplierEditDto> CreateSupplier(SupplierCreatingInput input)
	{
		Supplier supplier = ObjectMapper.Map<Supplier>(input);




		await _supplierRepository.InsertAsync(supplier);
		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<SupplierEditDto>(supplier);
	}

	public async Task<PagedResultDto<SupplierListDto>> GetSuppliers(GetSuppliersInput input)
	{
		var query = _supplierRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.Code.Contains(input.Filter) ||u.Name.Contains(input.Filter) ||u.Address.Contains(input.Filter) ||u.PhoneNumber.Contains(input.Filter) ||u.Email.Contains(input.Filter) ||u.TaxCode.Contains(input.Filter))


			  ;

		var count = await query.CountAsync();
		var result = await query.OrderBy(input.Sorting)
				.PageBy(input)
				.ToListAsync();
		var listDto = ObjectMapper.Map<List<SupplierListDto>>(result);
		return new PagedResultDto<SupplierListDto>(
				count,
				listDto
				);
	}

	public async Task<SupplierEditDto> GetSupplier(int id)
	{
		var supplier = await _supplierRepository.GetAsync(id);

		return ObjectMapper.Map<SupplierEditDto>(supplier);
	}

	public async Task<SupplierEditDto> EditSupplier(SupplierEditDto input)
	{
		var supplier = await _supplierRepository.GetAsync(input.Id);
		supplier.Code = input.Code;
		supplier.Name = input.Name;
		supplier.Address = input.Address;
		supplier.PhoneNumber = input.PhoneNumber;
		supplier.Email = input.Email;
		supplier.TaxCode = input.TaxCode;
		supplier.IsActive = input.IsActive;



		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<SupplierEditDto>(supplier);
	}

	// Permission??
	public async Task DeleteSupplier(int Id)
	{
		await  _supplierRepository.DeleteAsync(Id);
	}


	}
	////Suppliers AutoMapper
	//configuration.CreateMap<Supplier, SupplierEditDto>();
	//configuration.CreateMap<Supplier, SupplierListDto>();
	//configuration.CreateMap<SupplierCreatingInput, Supplier>();
