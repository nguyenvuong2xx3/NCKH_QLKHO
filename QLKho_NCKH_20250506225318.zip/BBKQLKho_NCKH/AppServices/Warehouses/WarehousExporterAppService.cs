﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using QLKho_NCKH.Entities;
using BBK.SaaS.Mdls.Categories;
using BBK.SaaS.Mdls.Categories.Dto;
using BBK.SaaS.Mdls.Categories.Entites;
using QLKho_NCKH.Warehouses.Dto;
using Abp.Extensions;
using Abp.Linq.Extensions;
using BBK.SaaS.BlobStoring;
using BBK.SaaS.Storage;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using BBK.SaaS.Dto;
using System.IO;
using MiniExcelLibs;
using BBK.SaaS.Mdls.Categories.Geographies;
using Abp.Domain.Uow;
using BBK.SaaS;

namespace QLKho_NCKH.Warehouses;


public interface IWarehousExporterAppService : IApplicationService
{
	Task<string> CheckErrorCreateDetail(WarehousImportDto input);
	Task<string> CheckErrorUpdateDetail(WarehousImportDto input);
}

public class WarehousExporterAppService : SaaSAppServiceBase, IWarehousExporterAppService
{
	private readonly IRepository<Warehous, long> _warehousRepository;
	//private readonly IBlobContainer _avatarContainer;
	private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly IRepository<GeoUnit, long> _geoUnitRepository;
 private readonly IRepository<CategoryUnit, long> _categoryUnitRepository;

	public WarehousExporterAppService(IRepository<Warehous, long> warehousRepository
		, IBlobContainerFactory blobContainerFactory
		, ITempFileCacheManager tempFileCacheManager,IRepository<GeoUnit, long> geoUnitRepository,
IRepository<CategoryUnit, long> categoryUnitRepository)
	{
		_warehousRepository = warehousRepository;
	_tempFileCacheManager = tempFileCacheManager;
 //_avatarContainer = blobContainerFactory.Create("");
 _geoUnitRepository = geoUnitRepository;
 _categoryUnitRepository = categoryUnitRepository;
	}

	public async Task<FileDto> ExportData(GetWarehousesExportOptionsInput input)
	{
using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
{
		var warehousQuery = _warehousRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.Code.Contains(input.Filter) ||u.Name.Contains(input.Filter) ||u.Location.Contains(input.Filter))

				.WhereIf(input.StartDate.HasValue, t => t.CreationTime >= input.StartDate.Value)
				.WhereIf(input.EndDate.HasValue, t => t.CreationTime <= input.EndDate.Value);

		var warehous = await warehousQuery.OrderBy(s => s.CreationTime).ThenBy(s => s.LastModificationTime ?? DateTime.MinValue).ToListAsync();

   var warehousListDtos = new List<WarehousListDto>();
foreach (var s in warehous)
{



warehousListDtos.Add(new WarehousListDto
{
Id  = s. Id,
Code  = s. Code,
Name  = s. Name,
Location  = s. Location,
TotalArea  = s. TotalArea,
IsActive  = s. IsActive,

//TenDiaChi = address,
//AvatarPath = avatarBase64,
});
}


if (input.ExportFileType == 0)
{
	return await ExportExcel( warehousListDtos);
}
else if (input.ExportFileType == 1)
{
		return await ExportExcelOptions( warehousListDtos, input);
}
//else if (input.ExportFileType == 2)
//{
//	return await ExportCsv( warehousListDtos);
//}
else if (input.ExportFileType == 3)
{
	return await ExportJson( warehousListDtos);
}
else
{
	throw new UserFriendlyException("Không hỗ trợ định dạng xuất file này");
}
	}

}

private async Task<FileDto> ExportJson(List<WarehousListDto> WarehousList)
{
var fileDto = new FileDto()
{
FileName = "Dữ liệu Warehous.json",
FileType = "application/json",
FileToken = Guid.NewGuid().ToString()
};

var jsonData = System.Text.Json.JsonSerializer.Serialize(WarehousList, new System.Text.Json.JsonSerializerOptions
{
WriteIndented = true
});

byte[] fileContent = Encoding.UTF8.GetBytes(jsonData);

_tempFileCacheManager.SetFile(fileDto.FileToken, fileContent);

return fileDto;
}


	private async Task<FileDto> ExportExcel(List<WarehousListDto> WarehousList)
{

  var allCategorieParents = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == null).ToListAsync();

  var country = await _geoUnitRepository.GetAll().Where(x => x.KeyName == "vi").ToListAsync();
  var allProvinces = await _geoUnitRepository.GetAll().Where(x => x.ParentId == country.FirstOrDefault().Id).OrderBy(x => x.OrderIndex).ToListAsync();

  var fileDto = new FileDto()
  {
    FileName = "Dữ liệu Warehous.xlsx",
    FileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    FileToken = Guid.NewGuid().ToString()
  };

  var excelData = new List<Dictionary<string, object>>();

  foreach (var s in WarehousList)
  {
  			var row = new Dictionary<string, object>
  {
   { "Code", s.Code},
   { "Name", s.Name},
   { "Location", s.Location},
   { "TotalArea", s.TotalArea},
   { "IsActive", s.IsActive},

  };

    excelData.Add(row);
  }

  var categoriesData = new List<Dictionary<string, object>>();
  foreach (var categorieParent in allCategorieParents)
  {
    if (categorieParent != null) // Đảm bảo rằng Id không phải null
    {
      var row = new Dictionary<string, object>
        {
          { "Mã nhập", categorieParent.Id },
          { "Danh mục hiển thị", categorieParent.DisplayName ?? "" },
          { "Loại danh mục", "" },
          { "Ghi chú", "" }
        };
      categoriesData.Add(row);
    }

    var allcategorieChilds = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == categorieParent.Id).ToListAsync();
    if (allcategorieChilds != null)
    {
      foreach (var categorieChild in allcategorieChilds)
      {
        if (categorieChild != null) // Đảm bảo rằng Id không phải null
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", categorieChild.Id },
            { "Danh mục hiển thị", categorieChild.DisplayName },
            { "Loại danh mục", categorieParent.DisplayName },
            { "Ghi chú", "Lưu ý: chỉ cần nhập id của danh mục" }
          };
          categoriesData.Add(row);
        }
      }
    }
  }


  var geossData = new List<Dictionary<string, object>>();
  foreach (var province in allProvinces)
  {
    if (province != null)
    {
      var row = new Dictionary<string, object>
      {
        { "Mã nhập", province.Id },
        { "Code", province.Code },
        { "Hiển thị", province.DisplayName ?? "" },
        { "Tỉnh/Thành phố", "x" },
        { "Quận/Huyện", "" },
        { "Xã/Phường", "" },
        { "Ghi chú", "" }
      };
      geossData.Add(row);
    }

    var allDistricts = await _geoUnitRepository.GetAll().Where(x => x.ParentId == province.Id).ToListAsync();
    if (allDistricts != null)
    {
      foreach (var district in allDistricts)
      {
        if (district != null)
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", district.Id },
            { "Code", district.Code },
            { "Hiển thị", district.DisplayName ?? "" },
            { "Tỉnh/Thành phố", "" },
            { "Quận/Huyện", "x" },
            { "Xã/Phường", "" },
            { "Ghi chú", "" }
          };
          geossData.Add(row);
        }

        var allWards = await _geoUnitRepository.GetAll().Where(x => x.ParentId == district.Id).ToListAsync();

        if (allWards != null)
        {
          foreach (var ward in allWards)
          {
            if (ward != null)
            {
              var row = new Dictionary<string, object>
              {
                { "Mã nhập", ward.Id },
                { "Code", ward.Code },
                { "Hiển thị", ward.DisplayName ?? "" },
                { "Tỉnh/Thành phố", "" },
                { "Quận/Huyện", "" },
                { "Xã/Phường", "x" },
                { "Ghi chú", "Lưu ý: chỉ cần nhập id của xã/phường" }
              };
              geossData.Add(row);
            }
          }

        }

      }
    }
  }

  using (var memoryStream = new MemoryStream())
  {
    memoryStream.SaveAs(new Dictionary<string, object>
    {
        { " WarehousDs", excelData },
        { "Danh mục", categoriesData },
        { "Địa chỉ", geossData }
    });

    _tempFileCacheManager.SetFile(fileDto.FileToken, memoryStream.ToArray());
  }

  return fileDto;
}

 private async Task<FileDto> ExportExcelOptions(List<WarehousListDto> WarehousList, GetWarehousesExportOptionsInput input)
{

  var allCategorieParents = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == null).ToListAsync();

  var country = await _geoUnitRepository.GetAll().Where(x => x.KeyName == "vi").ToListAsync();
  var allProvinces = await _geoUnitRepository.GetAll().Where(x => x.ParentId == country.FirstOrDefault().Id).OrderBy(x => x.OrderIndex).ToListAsync();

  var fileDto = new FileDto()
  {
    FileName = "Dữ liệu Warehous.xlsx",
    FileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    FileToken = Guid.NewGuid().ToString()
  };

  var excelData = new List<Dictionary<string, object>>();

  foreach (var s in WarehousList)
  {
			var row = new Dictionary<string, object>();
    row[L("Id")] = s.Id;
   if (input.IsDisplayCode ) row[L("Code")] = s.Code;
   if (input.IsDisplayName ) row[L("Name")] = s.Name;
   if (input.IsDisplayLocation ) row[L("Location")] = s.Location;
   if (input.IsDisplayTotalArea ) row[L("TotalArea")] = s.TotalArea;
   if (input.IsDisplayIsActive ) row[L("IsActive")] = s.IsActive;


    excelData.Add(row);
  }

  var categoriesData = new List<Dictionary<string, object>>();
  foreach (var categorieParent in allCategorieParents)
  {
    if (categorieParent != null) // Đảm bảo rằng Id không phải null
    {
      var row = new Dictionary<string, object>
        {
          { "Mã nhập", categorieParent.Id },
          { "Danh mục hiển thị", categorieParent.DisplayName ?? "" },
          { "Loại danh mục", "" },
          { "Ghi chú", "" }
        };
      categoriesData.Add(row);
    }

    var allcategorieChilds = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == categorieParent.Id).ToListAsync();
    if (allcategorieChilds != null)
    {
      foreach (var categorieChild in allcategorieChilds)
      {
        if (categorieChild != null) // Đảm bảo rằng Id không phải null
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", categorieChild.Id },
            { "Danh mục hiển thị", categorieChild.DisplayName },
            { "Loại danh mục", categorieParent.DisplayName },
            { "Ghi chú", "Lưu ý: chỉ cần nhập id của danh mục" }
          };
          categoriesData.Add(row);
        }
      }
    }
  }


  var geossData = new List<Dictionary<string, object>>();
  foreach (var province in allProvinces)
  {
    if (province != null)
    {
      var row = new Dictionary<string, object>
      {
        { "Mã nhập", province.Id },
        { "Code", province.Code },
        { "Hiển thị", province.DisplayName ?? "" },
        { "Tỉnh/Thành phố", "x" },
        { "Quận/Huyện", "" },
        { "Xã/Phường", "" },
        { "Ghi chú", "" }
      };
      geossData.Add(row);
    }

    var allDistricts = await _geoUnitRepository.GetAll().Where(x => x.ParentId == province.Id).ToListAsync();
    if (allDistricts != null)
    {
      foreach (var district in allDistricts)
      {
        if (district != null)
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", district.Id },
            { "Code", district.Code },
            { "Hiển thị", district.DisplayName ?? "" },
            { "Tỉnh/Thành phố", "" },
            { "Quận/Huyện", "x" },
            { "Xã/Phường", "" },
            { "Ghi chú", "" }
          };
          geossData.Add(row);
        }

        var allWards = await _geoUnitRepository.GetAll().Where(x => x.ParentId == district.Id).ToListAsync();

        if (allWards != null)
        {
          foreach (var ward in allWards)
          {
            if (ward != null)
            {
              var row = new Dictionary<string, object>
              {
                { "Mã nhập", ward.Id },
                { "Code", ward.Code },
                { "Hiển thị", ward.DisplayName ?? "" },
                { "Tỉnh/Thành phố", "" },
                { "Quận/Huyện", "" },
                { "Xã/Phường", "x" },
                { "Ghi chú", "Lưu ý: chỉ cần nhập id của xã/phường" }
              };
              geossData.Add(row);
            }
          }

        }

      }
    }
  }

  using (var memoryStream = new MemoryStream())
  {
    memoryStream.SaveAs(new Dictionary<string, object>
    {
        { " WarehousDs", excelData },
        { "Danh mục", categoriesData },
        { "Địa chỉ", geossData }
    });

    _tempFileCacheManager.SetFile(fileDto.FileToken, memoryStream.ToArray());
  }

  return fileDto;
}

public async Task<string> CheckErrorCreateDetail(WarehousImportDto input)
	{
	  using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
	  {
	  var duplicateDetails = new List<string>();
	  var errorDetails = new List<string>();
	  var formats = new[] { /*"dd/MM/yyyy", */"d/M/yyyy" };
	  var culture = System.Globalization.CultureInfo.InvariantCulture;









	  // Kiểm tra TotalArea
	  if (!input.TotalArea.IsNullOrWhiteSpace())
	  {
	      if (!decimal.TryParse(input.TotalArea, out var TotalArea))
	      {
	          errorDetails.Add($"TotalArea: '{input.TotalArea}' không hợp lệ");
	      }
	      else if (TotalArea <= 0)
	      {
	          errorDetails.Add($"TotalArea: '{input.TotalArea}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("TotalArea: Trường này là bắt buộc"); }

	  // Kiểm tra IsActive
	  if (!input.IsActive.IsNullOrWhiteSpace())
	  {
	      if (!bool.TryParse(input.IsActive, out var IsActive))
	      {
	          errorDetails.Add($"IsActive: '{input.IsActive}' không hợp lệ");
	      }
	  }
	  else { errorDetails.Add("IsActive: Trường này là bắt buộc"); }




	  if (!duplicateDetails.Any() && !errorDetails.Any())
	  return string.Empty;

	  var duplicate = duplicateDetails.Any() ? $"Trùng dữ liệu {string.Join(", ", duplicateDetails)}" : string.Empty;
	  var error = errorDetails.Any() ? $"Lỗi dữ liệu {string.Join(", ", errorDetails)}" : string.Empty;
	  var notification = string.Join(". ", new[] { duplicate, error }.Where(s => !string.IsNullOrEmpty(s)));
	  return notification;
	  }
	  }

	  public async Task<string> CheckErrorUpdateDetail(WarehousImportDto input)
   {
	  using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
	  {
	  var duplicateDetails = new List<string>();
	  var errorDetails = new List<string>();
	  var formats = new[] { /*"dd/MM/yyyy", */"d/M/yyyy" };
	  var culture = System.Globalization.CultureInfo.InvariantCulture;



  if (!long.TryParse(input.Id, out var Id))
  {
    errorDetails.Add($"Id: '{input.Id}' giá trị không hợp lệ");
  }
  else
  {
    var accommodationUnit = await _warehousRepository.FirstOrDefaultAsync(x => x.Id == Id);
    if (accommodationUnit != null)
    {

    }
    else if (accommodationUnit == null)
    {
       errorDetails.Add($"Id: '{input.Id}' không tồn tại");
    }
  }





	  // Kiểm tra TotalArea
	  if (!input.TotalArea.IsNullOrWhiteSpace())
	  {
	      if (!decimal.TryParse(input.TotalArea, out var TotalArea))
	      {
	          errorDetails.Add($"TotalArea: '{input.TotalArea}' không hợp lệ");
	      }
	      else if (TotalArea <= 0)
	      {
	          errorDetails.Add($"TotalArea: '{input.TotalArea}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("TotalArea: Trường này là bắt buộc"); }

	  // Kiểm tra IsActive
	  if (!input.IsActive.IsNullOrWhiteSpace())
	  {
	      if (!bool.TryParse(input.IsActive, out var IsActive))
	      {
	          errorDetails.Add($"IsActive: '{input.IsActive}' không hợp lệ");
	      }
	  }
	  else { errorDetails.Add("IsActive: Trường này là bắt buộc"); }



	  if (!duplicateDetails.Any() && !errorDetails.Any())
	  return string.Empty;

	  var duplicate = duplicateDetails.Any() ? $"Trùng dữ liệu {string.Join(", ", duplicateDetails)}" : string.Empty;
	  var error = errorDetails.Any() ? $"Lỗi dữ liệu {string.Join(", ", errorDetails)}" : string.Empty;
	  var notification = string.Join(". ", new[] { duplicate, error }.Where(s => !string.IsNullOrEmpty(s)));
	  return notification;
	  }
	}

}

