﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Abp.Linq.Extensions;
using BBK.SaaS;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using Abp.Extensions;
using Abp.Domain.Uow;
using QLKho_NCKH.QLKho_NCKH;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.Entities;
using QLKho_NCKH.Warehouses.Dto;

namespace QLKho_NCKH.Warehouses;



public class WarehousAppService :SaaSAppServiceBase, IWarehousAppService
{
 private readonly IRepository<Warehous, int> _warehousRepository;
 private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly MediaTypeManager MediaTypeManager;

 public WarehousAppService(IRepository<Warehous, int> warehousRepository
   , IBlobContainerFactory blobContainerFactory
   , ITempFileCacheManager tempFileCacheManager
   , MediaTypeManager mediaTypeManager

 )
 {
   _warehousRepository = warehousRepository;
   _tempFileCacheManager = tempFileCacheManager;
   MediaTypeManager = mediaTypeManager;
  }


	public async Task<WarehousEditDto> CreateWarehous(WarehousCreatingInput input)
	{
		Warehous warehous = ObjectMapper.Map<Warehous>(input);




		await _warehousRepository.InsertAsync(warehous);
		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<WarehousEditDto>(warehous);
	}

	public async Task<PagedResultDto<WarehousListDto>> GetWarehouses(GetWarehousesInput input)
	{
		var query = _warehousRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.Code.Contains(input.Filter) ||u.Name.Contains(input.Filter) ||u.Location.Contains(input.Filter))


			  ;

		var count = await query.CountAsync();
		var result = await query.OrderBy(input.Sorting)
				.PageBy(input)
				.ToListAsync();
		var listDto = ObjectMapper.Map<List<WarehousListDto>>(result);
		return new PagedResultDto<WarehousListDto>(
				count,
				listDto
				);
	}

	public async Task<WarehousEditDto> GetWarehous(int id)
	{
		var warehous = await _warehousRepository.GetAsync(id);

		return ObjectMapper.Map<WarehousEditDto>(warehous);
	}

	public async Task<WarehousEditDto> EditWarehous(WarehousEditDto input)
	{
		var warehous = await _warehousRepository.GetAsync(input.Id);
		warehous.Code = input.Code;
		warehous.Name = input.Name;
		warehous.Location = input.Location;
		warehous.TotalArea = input.TotalArea;
		warehous.IsActive = input.IsActive;



		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<WarehousEditDto>(warehous);
	}

	// Permission??
	public async Task DeleteWarehous(int Id)
	{
		await  _warehousRepository.DeleteAsync(Id);
	}


	}
	////Warehouss AutoMapper
	//configuration.CreateMap<Warehous, WarehousEditDto>();
	//configuration.CreateMap<Warehous, WarehousListDto>();
	//configuration.CreateMap<WarehousCreatingInput, Warehous>();
