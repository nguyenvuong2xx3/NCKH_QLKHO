﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using QLKho_NCKH.Entities;
using BBK.SaaS.Mdls.Categories;
using BBK.SaaS.Mdls.Categories.Dto;
using BBK.SaaS.Mdls.Categories.Entites;
using QLKho_NCKH.StockTransactionDetails.Dto;
using Abp.Extensions;
using Abp.Linq.Extensions;
using BBK.SaaS.BlobStoring;
using BBK.SaaS.Storage;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using BBK.SaaS.Dto;
using System.IO;
using MiniExcelLibs;
using BBK.SaaS.Mdls.Categories.Geographies;
using Abp.Domain.Uow;
using BBK.SaaS;

namespace QLKho_NCKH.StockTransactionDetails;


public interface IStockTransactionDetailExporterAppService : IApplicationService
{
	Task<string> CheckErrorCreateDetail(StockTransactionDetailImportDto input);
	Task<string> CheckErrorUpdateDetail(StockTransactionDetailImportDto input);
}

public class StockTransactionDetailExporterAppService : SaaSAppServiceBase, IStockTransactionDetailExporterAppService
{
	private readonly IRepository<StockTransactionDetail, long> _stockTransactionDetailRepository;
	//private readonly IBlobContainer _avatarContainer;
	private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly IRepository<GeoUnit, long> _geoUnitRepository;
 private readonly IRepository<CategoryUnit, long> _categoryUnitRepository;

	public StockTransactionDetailExporterAppService(IRepository<StockTransactionDetail, long> stockTransactionDetailRepository
		, IBlobContainerFactory blobContainerFactory
		, ITempFileCacheManager tempFileCacheManager,IRepository<GeoUnit, long> geoUnitRepository,
IRepository<CategoryUnit, long> categoryUnitRepository)
	{
		_stockTransactionDetailRepository = stockTransactionDetailRepository;
	_tempFileCacheManager = tempFileCacheManager;
 //_avatarContainer = blobContainerFactory.Create("");
 _geoUnitRepository = geoUnitRepository;
 _categoryUnitRepository = categoryUnitRepository;
	}

	public async Task<FileDto> ExportData(GetStockTransactionDetailsExportOptionsInput input)
	{
using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
{
		var stockTransactionDetailQuery = _stockTransactionDetailRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.Note.Contains(input.Filter) ||u.BatchNumber.Contains(input.Filter))

				.WhereIf(input.StartDate.HasValue, t => t.CreationTime >= input.StartDate.Value)
				.WhereIf(input.EndDate.HasValue, t => t.CreationTime <= input.EndDate.Value);

		var stockTransactionDetail = await stockTransactionDetailQuery.OrderBy(s => s.CreationTime).ThenBy(s => s.LastModificationTime ?? DateTime.MinValue).ToListAsync();

   var stockTransactionDetailListDtos = new List<StockTransactionDetailListDto>();
foreach (var s in stockTransactionDetail)
{



stockTransactionDetailListDtos.Add(new StockTransactionDetailListDto
{
StockTransactionId  = s. StockTransactionId,
ProductId  = s. ProductId,
StorageLocationId  = s. StorageLocationId,
Quantity  = s. Quantity,
UnitPrice  = s. UnitPrice,
Note  = s. Note,
BatchNumber  = s. BatchNumber,
ExpiryDate  = s. ExpiryDate,
Id  = s. Id,

//TenDiaChi = address,
//AvatarPath = avatarBase64,
});
}


if (input.ExportFileType == 0)
{
	return await ExportExcel( stockTransactionDetailListDtos);
}
else if (input.ExportFileType == 1)
{
		return await ExportExcelOptions( stockTransactionDetailListDtos, input);
}
//else if (input.ExportFileType == 2)
//{
//	return await ExportCsv( stockTransactionDetailListDtos);
//}
else if (input.ExportFileType == 3)
{
	return await ExportJson( stockTransactionDetailListDtos);
}
else
{
	throw new UserFriendlyException("Không hỗ trợ định dạng xuất file này");
}
	}

}

private async Task<FileDto> ExportJson(List<StockTransactionDetailListDto> StockTransactionDetailList)
{
var fileDto = new FileDto()
{
FileName = "Dữ liệu StockTransactionDetail.json",
FileType = "application/json",
FileToken = Guid.NewGuid().ToString()
};

var jsonData = System.Text.Json.JsonSerializer.Serialize(StockTransactionDetailList, new System.Text.Json.JsonSerializerOptions
{
WriteIndented = true
});

byte[] fileContent = Encoding.UTF8.GetBytes(jsonData);

_tempFileCacheManager.SetFile(fileDto.FileToken, fileContent);

return fileDto;
}


	private async Task<FileDto> ExportExcel(List<StockTransactionDetailListDto> StockTransactionDetailList)
{

  var allCategorieParents = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == null).ToListAsync();

  var country = await _geoUnitRepository.GetAll().Where(x => x.KeyName == "vi").ToListAsync();
  var allProvinces = await _geoUnitRepository.GetAll().Where(x => x.ParentId == country.FirstOrDefault().Id).OrderBy(x => x.OrderIndex).ToListAsync();

  var fileDto = new FileDto()
  {
    FileName = "Dữ liệu StockTransactionDetail.xlsx",
    FileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    FileToken = Guid.NewGuid().ToString()
  };

  var excelData = new List<Dictionary<string, object>>();

  foreach (var s in StockTransactionDetailList)
  {
  			var row = new Dictionary<string, object>
  {
   { "StockTransactionId", s.StockTransactionId},
   { "ProductId", s.ProductId},
   { "StorageLocationId", s.StorageLocationId},
   { "Quantity", s.Quantity},
   { "UnitPrice", s.UnitPrice},
   { "Note", s.Note},
   { "BatchNumber", s.BatchNumber},
   { "ExpiryDate", s.ExpiryDate},

  };

    excelData.Add(row);
  }

  var categoriesData = new List<Dictionary<string, object>>();
  foreach (var categorieParent in allCategorieParents)
  {
    if (categorieParent != null) // Đảm bảo rằng Id không phải null
    {
      var row = new Dictionary<string, object>
        {
          { "Mã nhập", categorieParent.Id },
          { "Danh mục hiển thị", categorieParent.DisplayName ?? "" },
          { "Loại danh mục", "" },
          { "Ghi chú", "" }
        };
      categoriesData.Add(row);
    }

    var allcategorieChilds = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == categorieParent.Id).ToListAsync();
    if (allcategorieChilds != null)
    {
      foreach (var categorieChild in allcategorieChilds)
      {
        if (categorieChild != null) // Đảm bảo rằng Id không phải null
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", categorieChild.Id },
            { "Danh mục hiển thị", categorieChild.DisplayName },
            { "Loại danh mục", categorieParent.DisplayName },
            { "Ghi chú", "Lưu ý: chỉ cần nhập id của danh mục" }
          };
          categoriesData.Add(row);
        }
      }
    }
  }


  var geossData = new List<Dictionary<string, object>>();
  foreach (var province in allProvinces)
  {
    if (province != null)
    {
      var row = new Dictionary<string, object>
      {
        { "Mã nhập", province.Id },
        { "Code", province.Code },
        { "Hiển thị", province.DisplayName ?? "" },
        { "Tỉnh/Thành phố", "x" },
        { "Quận/Huyện", "" },
        { "Xã/Phường", "" },
        { "Ghi chú", "" }
      };
      geossData.Add(row);
    }

    var allDistricts = await _geoUnitRepository.GetAll().Where(x => x.ParentId == province.Id).ToListAsync();
    if (allDistricts != null)
    {
      foreach (var district in allDistricts)
      {
        if (district != null)
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", district.Id },
            { "Code", district.Code },
            { "Hiển thị", district.DisplayName ?? "" },
            { "Tỉnh/Thành phố", "" },
            { "Quận/Huyện", "x" },
            { "Xã/Phường", "" },
            { "Ghi chú", "" }
          };
          geossData.Add(row);
        }

        var allWards = await _geoUnitRepository.GetAll().Where(x => x.ParentId == district.Id).ToListAsync();

        if (allWards != null)
        {
          foreach (var ward in allWards)
          {
            if (ward != null)
            {
              var row = new Dictionary<string, object>
              {
                { "Mã nhập", ward.Id },
                { "Code", ward.Code },
                { "Hiển thị", ward.DisplayName ?? "" },
                { "Tỉnh/Thành phố", "" },
                { "Quận/Huyện", "" },
                { "Xã/Phường", "x" },
                { "Ghi chú", "Lưu ý: chỉ cần nhập id của xã/phường" }
              };
              geossData.Add(row);
            }
          }

        }

      }
    }
  }

  using (var memoryStream = new MemoryStream())
  {
    memoryStream.SaveAs(new Dictionary<string, object>
    {
        { " StockTransactionDetailDs", excelData },
        { "Danh mục", categoriesData },
        { "Địa chỉ", geossData }
    });

    _tempFileCacheManager.SetFile(fileDto.FileToken, memoryStream.ToArray());
  }

  return fileDto;
}

 private async Task<FileDto> ExportExcelOptions(List<StockTransactionDetailListDto> StockTransactionDetailList, GetStockTransactionDetailsExportOptionsInput input)
{

  var allCategorieParents = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == null).ToListAsync();

  var country = await _geoUnitRepository.GetAll().Where(x => x.KeyName == "vi").ToListAsync();
  var allProvinces = await _geoUnitRepository.GetAll().Where(x => x.ParentId == country.FirstOrDefault().Id).OrderBy(x => x.OrderIndex).ToListAsync();

  var fileDto = new FileDto()
  {
    FileName = "Dữ liệu StockTransactionDetail.xlsx",
    FileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    FileToken = Guid.NewGuid().ToString()
  };

  var excelData = new List<Dictionary<string, object>>();

  foreach (var s in StockTransactionDetailList)
  {
			var row = new Dictionary<string, object>();
    row[L("Id")] = s.Id;
   if (input.IsDisplayStockTransactionId ) row[L("StockTransactionId")] = s.StockTransactionId;
   if (input.IsDisplayProductId ) row[L("ProductId")] = s.ProductId;
   if (input.IsDisplayStorageLocationId ) row[L("StorageLocationId")] = s.StorageLocationId;
   if (input.IsDisplayQuantity ) row[L("Quantity")] = s.Quantity;
   if (input.IsDisplayUnitPrice ) row[L("UnitPrice")] = s.UnitPrice;
   if (input.IsDisplayNote ) row[L("Note")] = s.Note;
   if (input.IsDisplayBatchNumber ) row[L("BatchNumber")] = s.BatchNumber;
   if (input.IsDisplayExpiryDate ) row[L("ExpiryDate")] = s.ExpiryDate;


    excelData.Add(row);
  }

  var categoriesData = new List<Dictionary<string, object>>();
  foreach (var categorieParent in allCategorieParents)
  {
    if (categorieParent != null) // Đảm bảo rằng Id không phải null
    {
      var row = new Dictionary<string, object>
        {
          { "Mã nhập", categorieParent.Id },
          { "Danh mục hiển thị", categorieParent.DisplayName ?? "" },
          { "Loại danh mục", "" },
          { "Ghi chú", "" }
        };
      categoriesData.Add(row);
    }

    var allcategorieChilds = await _categoryUnitRepository.GetAll().Where(x => x.ParentId == categorieParent.Id).ToListAsync();
    if (allcategorieChilds != null)
    {
      foreach (var categorieChild in allcategorieChilds)
      {
        if (categorieChild != null) // Đảm bảo rằng Id không phải null
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", categorieChild.Id },
            { "Danh mục hiển thị", categorieChild.DisplayName },
            { "Loại danh mục", categorieParent.DisplayName },
            { "Ghi chú", "Lưu ý: chỉ cần nhập id của danh mục" }
          };
          categoriesData.Add(row);
        }
      }
    }
  }


  var geossData = new List<Dictionary<string, object>>();
  foreach (var province in allProvinces)
  {
    if (province != null)
    {
      var row = new Dictionary<string, object>
      {
        { "Mã nhập", province.Id },
        { "Code", province.Code },
        { "Hiển thị", province.DisplayName ?? "" },
        { "Tỉnh/Thành phố", "x" },
        { "Quận/Huyện", "" },
        { "Xã/Phường", "" },
        { "Ghi chú", "" }
      };
      geossData.Add(row);
    }

    var allDistricts = await _geoUnitRepository.GetAll().Where(x => x.ParentId == province.Id).ToListAsync();
    if (allDistricts != null)
    {
      foreach (var district in allDistricts)
      {
        if (district != null)
        {
          var row = new Dictionary<string, object>
          {
            { "Mã nhập", district.Id },
            { "Code", district.Code },
            { "Hiển thị", district.DisplayName ?? "" },
            { "Tỉnh/Thành phố", "" },
            { "Quận/Huyện", "x" },
            { "Xã/Phường", "" },
            { "Ghi chú", "" }
          };
          geossData.Add(row);
        }

        var allWards = await _geoUnitRepository.GetAll().Where(x => x.ParentId == district.Id).ToListAsync();

        if (allWards != null)
        {
          foreach (var ward in allWards)
          {
            if (ward != null)
            {
              var row = new Dictionary<string, object>
              {
                { "Mã nhập", ward.Id },
                { "Code", ward.Code },
                { "Hiển thị", ward.DisplayName ?? "" },
                { "Tỉnh/Thành phố", "" },
                { "Quận/Huyện", "" },
                { "Xã/Phường", "x" },
                { "Ghi chú", "Lưu ý: chỉ cần nhập id của xã/phường" }
              };
              geossData.Add(row);
            }
          }

        }

      }
    }
  }

  using (var memoryStream = new MemoryStream())
  {
    memoryStream.SaveAs(new Dictionary<string, object>
    {
        { " StockTransactionDetailDs", excelData },
        { "Danh mục", categoriesData },
        { "Địa chỉ", geossData }
    });

    _tempFileCacheManager.SetFile(fileDto.FileToken, memoryStream.ToArray());
  }

  return fileDto;
}

public async Task<string> CheckErrorCreateDetail(StockTransactionDetailImportDto input)
	{
	  using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
	  {
	  var duplicateDetails = new List<string>();
	  var errorDetails = new List<string>();
	  var formats = new[] { /*"dd/MM/yyyy", */"d/M/yyyy" };
	  var culture = System.Globalization.CultureInfo.InvariantCulture;









	  // Kiểm tra StockTransactionId
	  if (!input.StockTransactionId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.StockTransactionId, out var StockTransactionId))
	      {
	          errorDetails.Add($"StockTransactionId: '{input.StockTransactionId}' không hợp lệ");
	      }
	      else if (StockTransactionId <= 0)
	      {
	          errorDetails.Add($"StockTransactionId: '{input.StockTransactionId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("StockTransactionId: Trường này là bắt buộc"); }

	  // Kiểm tra ProductId
	  if (!input.ProductId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.ProductId, out var ProductId))
	      {
	          errorDetails.Add($"ProductId: '{input.ProductId}' không hợp lệ");
	      }
	      else if (ProductId <= 0)
	      {
	          errorDetails.Add($"ProductId: '{input.ProductId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("ProductId: Trường này là bắt buộc"); }

	  // Kiểm tra StorageLocationId
	  if (!input.StorageLocationId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.StorageLocationId, out var StorageLocationId))
	      {
	          errorDetails.Add($"StorageLocationId: '{input.StorageLocationId}' không hợp lệ");
	      }
	      else if (StorageLocationId <= 0)
	      {
	          errorDetails.Add($"StorageLocationId: '{input.StorageLocationId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("StorageLocationId: Trường này là bắt buộc"); }

	  // Kiểm tra Quantity
	  if (!input.Quantity.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.Quantity, out var Quantity))
	      {
	          errorDetails.Add($"Quantity: '{input.Quantity}' không hợp lệ");
	      }
	      else if (Quantity <= 0)
	      {
	          errorDetails.Add($"Quantity: '{input.Quantity}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("Quantity: Trường này là bắt buộc"); }

	  // Kiểm tra UnitPrice
	  if (!input.UnitPrice.IsNullOrWhiteSpace())
	  {
	      if (!decimal.TryParse(input.UnitPrice, out var UnitPrice))
	      {
	          errorDetails.Add($"UnitPrice: '{input.UnitPrice}' không hợp lệ");
	      }
	      else if (UnitPrice <= 0)
	      {
	          errorDetails.Add($"UnitPrice: '{input.UnitPrice}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("UnitPrice: Trường này là bắt buộc"); }

	  // Kiểm tra ExpiryDate
	  if (!input.ExpiryDate.IsNullOrWhiteSpace())
	  {
	      if (!DateTime.TryParse(input.ExpiryDate, out var ExpiryDate))
	      {
	          errorDetails.Add($"ExpiryDate: '{input.ExpiryDate}' không hợp lệ");
	      }
	      else if (ExpiryDate.Year < 1900)
	      {
	          errorDetails.Add($"ExpiryDate: '{input.ExpiryDate}' không hợp lệ");
	      }
	  }





	  if (!duplicateDetails.Any() && !errorDetails.Any())
	  return string.Empty;

	  var duplicate = duplicateDetails.Any() ? $"Trùng dữ liệu {string.Join(", ", duplicateDetails)}" : string.Empty;
	  var error = errorDetails.Any() ? $"Lỗi dữ liệu {string.Join(", ", errorDetails)}" : string.Empty;
	  var notification = string.Join(". ", new[] { duplicate, error }.Where(s => !string.IsNullOrEmpty(s)));
	  return notification;
	  }
	  }

	  public async Task<string> CheckErrorUpdateDetail(StockTransactionDetailImportDto input)
   {
	  using (UnitOfWorkManager.Current.DisableFilter(AbpDataFilters.MayHaveTenant))
	  {
	  var duplicateDetails = new List<string>();
	  var errorDetails = new List<string>();
	  var formats = new[] { /*"dd/MM/yyyy", */"d/M/yyyy" };
	  var culture = System.Globalization.CultureInfo.InvariantCulture;



  if (!long.TryParse(input.Id, out var Id))
  {
    errorDetails.Add($"Id: '{input.Id}' giá trị không hợp lệ");
  }
  else
  {
    var accommodationUnit = await _stockTransactionDetailRepository.FirstOrDefaultAsync(x => x.Id == Id);
    if (accommodationUnit != null)
    {

    }
    else if (accommodationUnit == null)
    {
       errorDetails.Add($"Id: '{input.Id}' không tồn tại");
    }
  }





	  // Kiểm tra StockTransactionId
	  if (!input.StockTransactionId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.StockTransactionId, out var StockTransactionId))
	      {
	          errorDetails.Add($"StockTransactionId: '{input.StockTransactionId}' không hợp lệ");
	      }
	      else if (StockTransactionId <= 0)
	      {
	          errorDetails.Add($"StockTransactionId: '{input.StockTransactionId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("StockTransactionId: Trường này là bắt buộc"); }

	  // Kiểm tra ProductId
	  if (!input.ProductId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.ProductId, out var ProductId))
	      {
	          errorDetails.Add($"ProductId: '{input.ProductId}' không hợp lệ");
	      }
	      else if (ProductId <= 0)
	      {
	          errorDetails.Add($"ProductId: '{input.ProductId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("ProductId: Trường này là bắt buộc"); }

	  // Kiểm tra StorageLocationId
	  if (!input.StorageLocationId.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.StorageLocationId, out var StorageLocationId))
	      {
	          errorDetails.Add($"StorageLocationId: '{input.StorageLocationId}' không hợp lệ");
	      }
	      else if (StorageLocationId <= 0)
	      {
	          errorDetails.Add($"StorageLocationId: '{input.StorageLocationId}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("StorageLocationId: Trường này là bắt buộc"); }

	  // Kiểm tra Quantity
	  if (!input.Quantity.IsNullOrWhiteSpace())
	  {
	      if (!int.TryParse(input.Quantity, out var Quantity))
	      {
	          errorDetails.Add($"Quantity: '{input.Quantity}' không hợp lệ");
	      }
	      else if (Quantity <= 0)
	      {
	          errorDetails.Add($"Quantity: '{input.Quantity}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("Quantity: Trường này là bắt buộc"); }

	  // Kiểm tra UnitPrice
	  if (!input.UnitPrice.IsNullOrWhiteSpace())
	  {
	      if (!decimal.TryParse(input.UnitPrice, out var UnitPrice))
	      {
	          errorDetails.Add($"UnitPrice: '{input.UnitPrice}' không hợp lệ");
	      }
	      else if (UnitPrice <= 0)
	      {
	          errorDetails.Add($"UnitPrice: '{input.UnitPrice}' phải lớn hơn 0");
	      }
	  }
	  else { errorDetails.Add("UnitPrice: Trường này là bắt buộc"); }

	  // Kiểm tra ExpiryDate
	  if (!input.ExpiryDate.IsNullOrWhiteSpace())
	  {
	      if (!DateTime.TryParse(input.ExpiryDate, out var ExpiryDate))
	      {
	          errorDetails.Add($"ExpiryDate: '{input.ExpiryDate}' không hợp lệ");
	      }
	      else if (ExpiryDate.Year < 1900)
	      {
	          errorDetails.Add($"ExpiryDate: '{input.ExpiryDate}' không hợp lệ");
	      }
	  }




	  if (!duplicateDetails.Any() && !errorDetails.Any())
	  return string.Empty;

	  var duplicate = duplicateDetails.Any() ? $"Trùng dữ liệu {string.Join(", ", duplicateDetails)}" : string.Empty;
	  var error = errorDetails.Any() ? $"Lỗi dữ liệu {string.Join(", ", errorDetails)}" : string.Empty;
	  var notification = string.Join(". ", new[] { duplicate, error }.Where(s => !string.IsNullOrEmpty(s)));
	  return notification;
	  }
	}

}

