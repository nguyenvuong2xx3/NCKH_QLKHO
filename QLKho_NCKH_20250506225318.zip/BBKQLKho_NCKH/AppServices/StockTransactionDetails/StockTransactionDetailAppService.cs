﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Abp.Linq.Extensions;
using BBK.SaaS;
using Abp.UI;
using Abp.Authorization;
using Abp.Auditing;
using Abp.Extensions;
using Abp.Domain.Uow;
using QLKho_NCKH.QLKho_NCKH;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.Entities;
using QLKho_NCKH.StockTransactionDetails.Dto;

namespace QLKho_NCKH.StockTransactionDetails;



public class StockTransactionDetailAppService :SaaSAppServiceBase, IStockTransactionDetailAppService
{
 private readonly IRepository<StockTransactionDetail, int> _stockTransactionDetailRepository;
 private readonly ITempFileCacheManager _tempFileCacheManager;
 private readonly MediaTypeManager MediaTypeManager;

 public StockTransactionDetailAppService(IRepository<StockTransactionDetail, int> stockTransactionDetailRepository
   , IBlobContainerFactory blobContainerFactory
   , ITempFileCacheManager tempFileCacheManager
   , MediaTypeManager mediaTypeManager

 )
 {
   _stockTransactionDetailRepository = stockTransactionDetailRepository;
   _tempFileCacheManager = tempFileCacheManager;
   MediaTypeManager = mediaTypeManager;
  }


	public async Task<StockTransactionDetailEditDto> CreateStockTransactionDetail(StockTransactionDetailCreatingInput input)
	{
		StockTransactionDetail stockTransactionDetail = ObjectMapper.Map<StockTransactionDetail>(input);




		await _stockTransactionDetailRepository.InsertAsync(stockTransactionDetail);
		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<StockTransactionDetailEditDto>(stockTransactionDetail);
	}

	public async Task<PagedResultDto<StockTransactionDetailListDto>> GetStockTransactionDetails(GetStockTransactionDetailsInput input)
	{
		var query = _stockTransactionDetailRepository.GetAll()
				.WhereIf(!string.IsNullOrEmpty(input.Filter), u => u.Note.Contains(input.Filter) ||u.BatchNumber.Contains(input.Filter))


			  ;

		var count = await query.CountAsync();
		var result = await query.OrderBy(input.Sorting)
				.PageBy(input)
				.ToListAsync();
		var listDto = ObjectMapper.Map<List<StockTransactionDetailListDto>>(result);
		return new PagedResultDto<StockTransactionDetailListDto>(
				count,
				listDto
				);
	}

	public async Task<StockTransactionDetailEditDto> GetStockTransactionDetail(int id)
	{
		var stockTransactionDetail = await _stockTransactionDetailRepository.GetAsync(id);

		return ObjectMapper.Map<StockTransactionDetailEditDto>(stockTransactionDetail);
	}

	public async Task<StockTransactionDetailEditDto> EditStockTransactionDetail(StockTransactionDetailEditDto input)
	{
		var stockTransactionDetail = await _stockTransactionDetailRepository.GetAsync(input.Id);
		stockTransactionDetail.StockTransactionId = input.StockTransactionId;
		stockTransactionDetail.ProductId = input.ProductId;
		stockTransactionDetail.StorageLocationId = input.StorageLocationId;
		stockTransactionDetail.Quantity = input.Quantity;
		stockTransactionDetail.UnitPrice = input.UnitPrice;
		stockTransactionDetail.Note = input.Note;
		stockTransactionDetail.BatchNumber = input.BatchNumber;
		stockTransactionDetail.ExpiryDate = input.ExpiryDate;



		await CurrentUnitOfWork.SaveChangesAsync();

		return ObjectMapper.Map<StockTransactionDetailEditDto>(stockTransactionDetail);
	}

	// Permission??
	public async Task DeleteStockTransactionDetail(int Id)
	{
		await  _stockTransactionDetailRepository.DeleteAsync(Id);
	}


	}
	////StockTransactionDetails AutoMapper
	//configuration.CreateMap<StockTransactionDetail, StockTransactionDetailEditDto>();
	//configuration.CreateMap<StockTransactionDetail, StockTransactionDetailListDto>();
	//configuration.CreateMap<StockTransactionDetailCreatingInput, StockTransactionDetail>();
