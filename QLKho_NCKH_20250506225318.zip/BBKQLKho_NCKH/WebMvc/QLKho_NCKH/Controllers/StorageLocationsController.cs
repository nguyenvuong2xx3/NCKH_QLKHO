﻿using System.Threading.Tasks;
using Abp.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.QLKho_NCKH.Web.Controllers;
using QLKho_NCKH.StorageLocations;
using QLKho_NCKH.StorageLocations.Dto;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.StorageLocations;
using Microsoft.AspNetCore.Http;
using Abp.Web.Models;
using System;
using Abp.IO.Extensions;
using QLKho_NCKH.QLKho_NCKH.Mdls.Categories;
using System.Linq;
using QLKho_NCKH.QLKho_NCKH.Graphics;
using QLKho_NCKH.QLKho_NCKH.Dto;
using Abp.UI;
using Abp.Auditing;
using Microsoft.AspNetCore.Http.Headers;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using System.IO;
using MiniExcelLibs;
using QLKho_NCKH.QLKho_NCKH.Web.Areas.App.Models.Common;
using Abp.Application.Services.Dto;
using QLKho_NCKH.QLKho_NCKH.Net;
using Abp.Collections.Extensions;
using BBK.SaaS.Authorization.Users;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Controllers;

 [Area("QLKho_NCKH")]
 [AbpMvcAuthorize]
 public class StorageLocationsController : SaaSControllerBase
 {
   private readonly IStorageLocationAppService _storageLocationAppService;
   private readonly IStorageLocationExporterAppService _storageLocationExporterAppService;
   public StorageLocationsController(
     IStorageLocationAppService storageLocationAppService
     , IStorageLocationExporterAppService storageLocationExporterAppService
   )
   {
     _storageLocationAppService = storageLocationAppService;
   _storageLocationExporterAppService = storageLocationExporterAppService;
    }


   public async Task<IActionResult> CreateModal()
   {
       var viewModel = new StorageLocationCreateViewModel //StorageLocationEditContainer
       {
         StorageLocation = new StorageLocationCreatingInput()
       };


        return PartialView("_CreateModal",viewModel);
   }

   public async Task<IActionResult> Index()
   {


       return View();
   }

   public async Task<IActionResult> EditModal(int id)
   {
       var dto = await _storageLocationAppService.GetStorageLocation(id);
       var viewModel = new StorageLocationEditViewModel { StorageLocation = dto };



       return PartialView("_EditModal", viewModel);
   }

   public async Task<IActionResult>DetailModal(int id)
   {
       var dto = await _storageLocationAppService.GetStorageLocation(id);

       var viewModel = new StorageLocationEditViewModel
       {
         StorageLocation = dto
       };


       return PartialView("_DetailModal",viewModel);
   }

        public async Task<IActionResult> ExportDataModal()
        {
            return PartialView("_ExportDataModal");
        }
        public async Task<IActionResult> ImportDataModal()
        {
            return PartialView("_ImportDataModal");
        }

        [HttpPost]
        public async Task<IActionResult> ImportData(IFormFile file)
        {
            if (file == null || file.Length <= 0)
                return Content("{\"success\": false, \"message\": \"File chưa được upload.\"}");

            var totalRecords = 0;
            var successfulImports = 0;
            var failedImports = 0;
            var errorList = new List<string>();

            try
            {
                var (listImport, listError) = await ParseFileAsync(file);
                totalRecords = listImport.Count;
                errorList = listError;

                foreach (var import in listImport)
                {
                    string checkError;
                    if (!import.Id.IsNullOrEmpty())
                    {
                        checkError = await _storageLocationExporterAppService.CheckErrorUpdateDetail(import);
                        if (checkError.IsNullOrEmpty())
                        {
                            var updateDto = new StorageLocationEditDto()
                            {
                              Id = long.TryParse(import.Id, out var id) ? id : 0,
                              Code = import.Code,
                              WarehouseId = int.TryParse(import.WarehouseId, out var WarehouseId) ? WarehouseId : 0,
                              Capacity = decimal.TryParse(import.Capacity, out var Capacity) ? Capacity : 0,
                              CurrentVolume = decimal.TryParse(import.CurrentVolume, out var CurrentVolume) ? CurrentVolume : 0,
                              IsAvailable = bool.TryParse(import.IsAvailable, out var IsAvailable) ? IsAvailable : false,

                            };
                            await _storageLocationAppService.EditStorageLocation(updateDto);
                            successfulImports++;
                        }
                        else
                        {
                            failedImports++;
                            errorList.Add($"storageLocation (Id: {import.Id}): {checkError}");
                        }
                    }
                    else
                    {
                        checkError = await _storageLocationExporterAppService.CheckErrorCreateDetail(import);
                        if (checkError.IsNullOrEmpty())
                        {
                            var createDto = new StorageLocationCreatingInput()
                            {
                              Code = import.Code,
                              WarehouseId = int.TryParse(import.WarehouseId, out var WarehouseId) ? WarehouseId : 0,
                              Capacity = decimal.TryParse(import.Capacity, out var Capacity) ? Capacity : 0,
                              CurrentVolume = decimal.TryParse(import.CurrentVolume, out var CurrentVolume) ? CurrentVolume : 0,
                              IsAvailable = bool.TryParse(import.IsAvailable, out var IsAvailable) ? IsAvailable : false,

                            };
                            await _storageLocationAppService.CreateStorageLocation(createDto);
                            successfulImports++;
                        }
                        else
                        {
                            failedImports++;
                            errorList.Add($"storageLocation (Name: {import.Code ?? "N/A"}): {checkError}");
                        }
                    }
                }
                return Content(JsonConvert.SerializeObject(new
                {
	                success = true,
	                message = "Upload file thành công.",
	                totalRecords,
	                successfulImports,
	                failedImports,
	                errors = errorList
                }), "application/json");
            }
            catch (Exception ex)
	          {
		          Console.WriteLine(ex.Message);
		          return Content(JsonConvert.SerializeObject(new
		          {
			          success = false,
			          message = "Có lỗi: " + ex.Message,
			          totalRecords,
			          successfulImports,
			          failedImports,
			          errors = errorList
		          }), "application/json");
	          }
        }

        private async Task<(List<StorageLocationImportDto> listImport, List<string> listError)> ParseFileAsync(IFormFile file)
        {
            var listImport = new List<StorageLocationImportDto>();
            var errorList = new List<string>();
            var fileExtension = Path.GetExtension(file.FileName).ToLower();

            if (fileExtension == ".json")
            {
                using var stream = file.OpenReadStream();
                using var reader = new StreamReader(stream);
                var fileContent = await reader.ReadToEndAsync();
                listImport = JsonConvert.DeserializeObject<List<StorageLocationImportDto>>(fileContent);
            }
            else if (fileExtension == ".xlsx")
            {
                using var memoryStream = new MemoryStream();
                file.CopyTo(memoryStream);
                memoryStream.Position = 0;

                var rawRows = MiniExcel.Query(memoryStream, useHeaderRow: true).ToList();
                using var filteredStream = new MemoryStream();
                MiniExcel.SaveAs(filteredStream, rawRows);
                filteredStream.Position = 0;

                try
                {
                    listImport = MiniExcel.Query<StorageLocationImportDto>(filteredStream).Where(row => !IsRowInvalid(row)).ToList();
                }
                catch (Exception ex)
                {
                    var errorDetails = ex.Message.Split(':');
                    var errorMsg = errorDetails.Length > 3 ? errorDetails[3].Trim() : "Lỗi không xác định";
                    errorList.Add($"Lỗi dòng {errorDetails[2].Trim().Split(',')[0]}: {errorMsg}");
                }
            }
            else
            {
                throw new Exception("Loại tệp không được hỗ trợ.");
            }
            return (listImport, errorList);
        }

        private bool IsRowInvalid(StorageLocationImportDto row)
        {
            return row == null || (
                
                string.IsNullOrWhiteSpace(row.Code)&&

                string.IsNullOrWhiteSpace(row.WarehouseId)&&

                string.IsNullOrWhiteSpace(row.Capacity)&&

                string.IsNullOrWhiteSpace(row.CurrentVolume)&&

                string.IsNullOrWhiteSpace(row.IsAvailable)

            );
    }
 }
