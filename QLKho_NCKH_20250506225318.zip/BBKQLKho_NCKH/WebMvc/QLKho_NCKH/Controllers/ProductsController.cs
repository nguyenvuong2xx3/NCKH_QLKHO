﻿using System.Threading.Tasks;
using Abp.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.QLKho_NCKH.Web.Controllers;
using QLKho_NCKH.Products;
using QLKho_NCKH.Products.Dto;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.Products;
using Microsoft.AspNetCore.Http;
using Abp.Web.Models;
using System;
using Abp.IO.Extensions;
using QLKho_NCKH.QLKho_NCKH.Mdls.Categories;
using System.Linq;
using QLKho_NCKH.QLKho_NCKH.Graphics;
using QLKho_NCKH.QLKho_NCKH.Dto;
using Abp.UI;
using Abp.Auditing;
using Microsoft.AspNetCore.Http.Headers;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using System.IO;
using MiniExcelLibs;
using QLKho_NCKH.QLKho_NCKH.Web.Areas.App.Models.Common;
using Abp.Application.Services.Dto;
using QLKho_NCKH.QLKho_NCKH.Net;
using Abp.Collections.Extensions;
using BBK.SaaS.Authorization.Users;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Controllers;

 [Area("QLKho_NCKH")]
 [AbpMvcAuthorize]
 public class ProductsController : SaaSControllerBase
 {
   private readonly IProductAppService _productAppService;
   private readonly IProductExporterAppService _productExporterAppService;
   public ProductsController(
     IProductAppService productAppService
     , IProductExporterAppService productExporterAppService
   )
   {
     _productAppService = productAppService;
   _productExporterAppService = productExporterAppService;
    }


   public async Task<IActionResult> CreateModal()
   {
       var viewModel = new ProductCreateViewModel //ProductEditContainer
       {
         Product = new ProductCreatingInput()
       };


        return PartialView("_CreateModal",viewModel);
   }

   public async Task<IActionResult> Index()
   {


       return View();
   }

   public async Task<IActionResult> EditModal(int id)
   {
       var dto = await _productAppService.GetProduct(id);
       var viewModel = new ProductEditViewModel { Product = dto };



       return PartialView("_EditModal", viewModel);
   }

   public async Task<IActionResult>DetailModal(int id)
   {
       var dto = await _productAppService.GetProduct(id);

       var viewModel = new ProductEditViewModel
       {
         Product = dto
       };


       return PartialView("_DetailModal",viewModel);
   }

        public async Task<IActionResult> ExportDataModal()
        {
            return PartialView("_ExportDataModal");
        }
        public async Task<IActionResult> ImportDataModal()
        {
            return PartialView("_ImportDataModal");
        }

        [HttpPost]
        public async Task<IActionResult> ImportData(IFormFile file)
        {
            if (file == null || file.Length <= 0)
                return Content("{\"success\": false, \"message\": \"File chưa được upload.\"}");

            var totalRecords = 0;
            var successfulImports = 0;
            var failedImports = 0;
            var errorList = new List<string>();

            try
            {
                var (listImport, listError) = await ParseFileAsync(file);
                totalRecords = listImport.Count;
                errorList = listError;

                foreach (var import in listImport)
                {
                    string checkError;
                    if (!import.Id.IsNullOrEmpty())
                    {
                        checkError = await _productExporterAppService.CheckErrorUpdateDetail(import);
                        if (checkError.IsNullOrEmpty())
                        {
                            var updateDto = new ProductEditDto()
                            {
                              Id = long.TryParse(import.Id, out var id) ? id : 0,
                              Code = import.Code,
                              Name = import.Name,
                              Description = import.Description,
                              CategoryId = int.TryParse(import.CategoryId, out var CategoryId) ? CategoryId : (int?)null,
                              Barcode = import.Barcode,
                              Unit = import.Unit,
                              Weight = decimal.TryParse(import.Weight, out var Weight) ? Weight : 0,
                              Volume = decimal.TryParse(import.Volume, out var Volume) ? Volume : 0,
                              IsActive = bool.TryParse(import.IsActive, out var IsActive) ? IsActive : false,
                              SupplierId = int.TryParse(import.SupplierId, out var SupplierId) ? SupplierId : (int?)null,
                              Image = import.Image,

                            };
                            await _productAppService.EditProduct(updateDto);
                            successfulImports++;
                        }
                        else
                        {
                            failedImports++;
                            errorList.Add($"product (Id: {import.Id}): {checkError}");
                        }
                    }
                    else
                    {
                        checkError = await _productExporterAppService.CheckErrorCreateDetail(import);
                        if (checkError.IsNullOrEmpty())
                        {
                            var createDto = new ProductCreatingInput()
                            {
                              Code = import.Code,
                              Name = import.Name,
                              Description = import.Description,
                              CategoryId = int.TryParse(import.CategoryId, out var CategoryId) ? CategoryId : (int?)null,
                              Barcode = import.Barcode,
                              Unit = import.Unit,
                              Weight = decimal.TryParse(import.Weight, out var Weight) ? Weight : 0,
                              Volume = decimal.TryParse(import.Volume, out var Volume) ? Volume : 0,
                              IsActive = bool.TryParse(import.IsActive, out var IsActive) ? IsActive : false,
                              SupplierId = int.TryParse(import.SupplierId, out var SupplierId) ? SupplierId : (int?)null,
                              Image = import.Image,

                            };
                            await _productAppService.CreateProduct(createDto);
                            successfulImports++;
                        }
                        else
                        {
                            failedImports++;
                            errorList.Add($"product (Name: {import.Code ?? "N/A"}): {checkError}");
                        }
                    }
                }
                return Content(JsonConvert.SerializeObject(new
                {
	                success = true,
	                message = "Upload file thành công.",
	                totalRecords,
	                successfulImports,
	                failedImports,
	                errors = errorList
                }), "application/json");
            }
            catch (Exception ex)
	          {
		          Console.WriteLine(ex.Message);
		          return Content(JsonConvert.SerializeObject(new
		          {
			          success = false,
			          message = "Có lỗi: " + ex.Message,
			          totalRecords,
			          successfulImports,
			          failedImports,
			          errors = errorList
		          }), "application/json");
	          }
        }

        private async Task<(List<ProductImportDto> listImport, List<string> listError)> ParseFileAsync(IFormFile file)
        {
            var listImport = new List<ProductImportDto>();
            var errorList = new List<string>();
            var fileExtension = Path.GetExtension(file.FileName).ToLower();

            if (fileExtension == ".json")
            {
                using var stream = file.OpenReadStream();
                using var reader = new StreamReader(stream);
                var fileContent = await reader.ReadToEndAsync();
                listImport = JsonConvert.DeserializeObject<List<ProductImportDto>>(fileContent);
            }
            else if (fileExtension == ".xlsx")
            {
                using var memoryStream = new MemoryStream();
                file.CopyTo(memoryStream);
                memoryStream.Position = 0;

                var rawRows = MiniExcel.Query(memoryStream, useHeaderRow: true).ToList();
                using var filteredStream = new MemoryStream();
                MiniExcel.SaveAs(filteredStream, rawRows);
                filteredStream.Position = 0;

                try
                {
                    listImport = MiniExcel.Query<ProductImportDto>(filteredStream).Where(row => !IsRowInvalid(row)).ToList();
                }
                catch (Exception ex)
                {
                    var errorDetails = ex.Message.Split(':');
                    var errorMsg = errorDetails.Length > 3 ? errorDetails[3].Trim() : "Lỗi không xác định";
                    errorList.Add($"Lỗi dòng {errorDetails[2].Trim().Split(',')[0]}: {errorMsg}");
                }
            }
            else
            {
                throw new Exception("Loại tệp không được hỗ trợ.");
            }
            return (listImport, errorList);
        }

        private bool IsRowInvalid(ProductImportDto row)
        {
            return row == null || (
                
                string.IsNullOrWhiteSpace(row.Code)&&

                string.IsNullOrWhiteSpace(row.Name)&&

                string.IsNullOrWhiteSpace(row.Description)&&

                string.IsNullOrWhiteSpace(row.CategoryId)&&

                string.IsNullOrWhiteSpace(row.Barcode)&&

                string.IsNullOrWhiteSpace(row.Unit)&&

                string.IsNullOrWhiteSpace(row.Weight)&&

                string.IsNullOrWhiteSpace(row.Volume)&&

                string.IsNullOrWhiteSpace(row.IsActive)&&

                string.IsNullOrWhiteSpace(row.SupplierId)&&

                string.IsNullOrWhiteSpace(row.Image)

            );
    }
 }
