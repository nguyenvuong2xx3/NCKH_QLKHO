﻿using System.Threading.Tasks;
using Abp.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.QLKho_NCKH.Web.Controllers;
using QLKho_NCKH.InventoryItems;
using QLKho_NCKH.InventoryItems.Dto;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.InventoryItems;
using Microsoft.AspNetCore.Http;
using Abp.Web.Models;
using System;
using Abp.IO.Extensions;
using QLKho_NCKH.QLKho_NCKH.Mdls.Categories;
using System.Linq;
using QLKho_NCKH.QLKho_NCKH.Graphics;
using QLKho_NCKH.QLKho_NCKH.Dto;
using Abp.UI;
using Abp.Auditing;
using Microsoft.AspNetCore.Http.Headers;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using System.IO;
using MiniExcelLibs;
using QLKho_NCKH.QLKho_NCKH.Web.Areas.App.Models.Common;
using Abp.Application.Services.Dto;
using QLKho_NCKH.QLKho_NCKH.Net;
using Abp.Collections.Extensions;
using BBK.SaaS.Authorization.Users;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Controllers;

 [Area("QLKho_NCKH")]
 [AbpMvcAuthorize]
 public class InventoryItemsController : SaaSControllerBase
 {
   private readonly IInventoryItemAppService _inventoryItemAppService;
   private readonly IInventoryItemExporterAppService _inventoryItemExporterAppService;
   public InventoryItemsController(
     IInventoryItemAppService inventoryItemAppService
     , IInventoryItemExporterAppService inventoryItemExporterAppService
   )
   {
     _inventoryItemAppService = inventoryItemAppService;
   _inventoryItemExporterAppService = inventoryItemExporterAppService;
    }


   public async Task<IActionResult> CreateModal()
   {
       var viewModel = new InventoryItemCreateViewModel //InventoryItemEditContainer
       {
         InventoryItem = new InventoryItemCreatingInput()
       };


        return PartialView("_CreateModal",viewModel);
   }

   public async Task<IActionResult> Index()
   {


       return View();
   }

   public async Task<IActionResult> EditModal(int id)
   {
       var dto = await _inventoryItemAppService.GetInventoryItem(id);
       var viewModel = new InventoryItemEditViewModel { InventoryItem = dto };



       return PartialView("_EditModal", viewModel);
   }

   public async Task<IActionResult>DetailModal(int id)
   {
       var dto = await _inventoryItemAppService.GetInventoryItem(id);

       var viewModel = new InventoryItemEditViewModel
       {
         InventoryItem = dto
       };


       return PartialView("_DetailModal",viewModel);
   }

        public async Task<IActionResult> ExportDataModal()
        {
            return PartialView("_ExportDataModal");
        }
        public async Task<IActionResult> ImportDataModal()
        {
            return PartialView("_ImportDataModal");
        }

        [HttpPost]
        public async Task<IActionResult> ImportData(IFormFile file)
        {
            if (file == null || file.Length <= 0)
                return Content("{\"success\": false, \"message\": \"File chưa được upload.\"}");

            var totalRecords = 0;
            var successfulImports = 0;
            var failedImports = 0;
            var errorList = new List<string>();

            try
            {
                var (listImport, listError) = await ParseFileAsync(file);
                totalRecords = listImport.Count;
                errorList = listError;

                foreach (var import in listImport)
                {
                    string checkError;
                    if (!import.Id.IsNullOrEmpty())
                    {
                        checkError = await _inventoryItemExporterAppService.CheckErrorUpdateDetail(import);
                        if (checkError.IsNullOrEmpty())
                        {
                            var updateDto = new InventoryItemEditDto()
                            {
                              Id = long.TryParse(import.Id, out var id) ? id : 0,
                              ProductId = int.TryParse(import.ProductId, out var ProductId) ? ProductId : 0,
                              StorageLocationId = int.TryParse(import.StorageLocationId, out var StorageLocationId) ? StorageLocationId : 0,
                              Quantity = int.TryParse(import.Quantity, out var Quantity) ? Quantity : 0,
                              ReservedQuantity = int.TryParse(import.ReservedQuantity, out var ReservedQuantity) ? ReservedQuantity : 0,
                              UnitPrice = decimal.TryParse(import.UnitPrice, out var UnitPrice) ? UnitPrice : 0,

                            };
                            await _inventoryItemAppService.EditInventoryItem(updateDto);
                            successfulImports++;
                        }
                        else
                        {
                            failedImports++;
                            errorList.Add($"inventoryItem (Id: {import.Id}): {checkError}");
                        }
                    }
                    else
                    {
                        checkError = await _inventoryItemExporterAppService.CheckErrorCreateDetail(import);
                        if (checkError.IsNullOrEmpty())
                        {
                            var createDto = new InventoryItemCreatingInput()
                            {
                              ProductId = int.TryParse(import.ProductId, out var ProductId) ? ProductId : 0,
                              StorageLocationId = int.TryParse(import.StorageLocationId, out var StorageLocationId) ? StorageLocationId : 0,
                              Quantity = int.TryParse(import.Quantity, out var Quantity) ? Quantity : 0,
                              ReservedQuantity = int.TryParse(import.ReservedQuantity, out var ReservedQuantity) ? ReservedQuantity : 0,
                              UnitPrice = decimal.TryParse(import.UnitPrice, out var UnitPrice) ? UnitPrice : 0,

                            };
                            await _inventoryItemAppService.CreateInventoryItem(createDto);
                            successfulImports++;
                        }
                        else
                        {
                            failedImports++;
                            errorList.Add($"inventoryItem (Name: {import.ProductId ?? "N/A"}): {checkError}");
                        }
                    }
                }
                return Content(JsonConvert.SerializeObject(new
                {
	                success = true,
	                message = "Upload file thành công.",
	                totalRecords,
	                successfulImports,
	                failedImports,
	                errors = errorList
                }), "application/json");
            }
            catch (Exception ex)
	          {
		          Console.WriteLine(ex.Message);
		          return Content(JsonConvert.SerializeObject(new
		          {
			          success = false,
			          message = "Có lỗi: " + ex.Message,
			          totalRecords,
			          successfulImports,
			          failedImports,
			          errors = errorList
		          }), "application/json");
	          }
        }

        private async Task<(List<InventoryItemImportDto> listImport, List<string> listError)> ParseFileAsync(IFormFile file)
        {
            var listImport = new List<InventoryItemImportDto>();
            var errorList = new List<string>();
            var fileExtension = Path.GetExtension(file.FileName).ToLower();

            if (fileExtension == ".json")
            {
                using var stream = file.OpenReadStream();
                using var reader = new StreamReader(stream);
                var fileContent = await reader.ReadToEndAsync();
                listImport = JsonConvert.DeserializeObject<List<InventoryItemImportDto>>(fileContent);
            }
            else if (fileExtension == ".xlsx")
            {
                using var memoryStream = new MemoryStream();
                file.CopyTo(memoryStream);
                memoryStream.Position = 0;

                var rawRows = MiniExcel.Query(memoryStream, useHeaderRow: true).ToList();
                using var filteredStream = new MemoryStream();
                MiniExcel.SaveAs(filteredStream, rawRows);
                filteredStream.Position = 0;

                try
                {
                    listImport = MiniExcel.Query<InventoryItemImportDto>(filteredStream).Where(row => !IsRowInvalid(row)).ToList();
                }
                catch (Exception ex)
                {
                    var errorDetails = ex.Message.Split(':');
                    var errorMsg = errorDetails.Length > 3 ? errorDetails[3].Trim() : "Lỗi không xác định";
                    errorList.Add($"Lỗi dòng {errorDetails[2].Trim().Split(',')[0]}: {errorMsg}");
                }
            }
            else
            {
                throw new Exception("Loại tệp không được hỗ trợ.");
            }
            return (listImport, errorList);
        }

        private bool IsRowInvalid(InventoryItemImportDto row)
        {
            return row == null || (
                
                string.IsNullOrWhiteSpace(row.ProductId)&&

                string.IsNullOrWhiteSpace(row.StorageLocationId)&&

                string.IsNullOrWhiteSpace(row.Quantity)&&

                string.IsNullOrWhiteSpace(row.ReservedQuantity)&&

                string.IsNullOrWhiteSpace(row.UnitPrice)

            );
    }
 }
