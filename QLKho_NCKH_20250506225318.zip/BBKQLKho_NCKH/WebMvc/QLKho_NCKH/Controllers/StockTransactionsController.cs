﻿using System.Threading.Tasks;
using Abp.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using QLKho_NCKH.QLKho_NCKH.Storage;
using QLKho_NCKH.QLKho_NCKH.Web.Controllers;
using QLKho_NCKH.StockTransactions;
using QLKho_NCKH.StockTransactions.Dto;
using QLKho_NCKH.QLKho_NCKH.BlobStoring;
using QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.StockTransactions;
using Microsoft.AspNetCore.Http;
using Abp.Web.Models;
using System;
using Abp.IO.Extensions;
using QLKho_NCKH.QLKho_NCKH.Mdls.Categories;
using System.Linq;
using QLKho_NCKH.QLKho_NCKH.Graphics;
using QLKho_NCKH.QLKho_NCKH.Dto;
using Abp.UI;
using Abp.Auditing;
using Microsoft.AspNetCore.Http.Headers;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using System.IO;
using MiniExcelLibs;
using QLKho_NCKH.QLKho_NCKH.Web.Areas.App.Models.Common;
using Abp.Application.Services.Dto;
using QLKho_NCKH.QLKho_NCKH.Net;
using Abp.Collections.Extensions;
using BBK.SaaS.Authorization.Users;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Controllers;

 [Area("QLKho_NCKH")]
 [AbpMvcAuthorize]
 public class StockTransactionsController : SaaSControllerBase
 {
   private readonly IStockTransactionAppService _stockTransactionAppService;
   private readonly IStockTransactionExporterAppService _stockTransactionExporterAppService;
   public StockTransactionsController(
     IStockTransactionAppService stockTransactionAppService
     , IStockTransactionExporterAppService stockTransactionExporterAppService
   )
   {
     _stockTransactionAppService = stockTransactionAppService;
   _stockTransactionExporterAppService = stockTransactionExporterAppService;
    }


   public async Task<IActionResult> CreateModal()
   {
       var viewModel = new StockTransactionCreateViewModel //StockTransactionEditContainer
       {
         StockTransaction = new StockTransactionCreatingInput()
       };


        return PartialView("_CreateModal",viewModel);
   }

   public async Task<IActionResult> Index()
   {


       return View();
   }

   public async Task<IActionResult> EditModal(int id)
   {
       var dto = await _stockTransactionAppService.GetStockTransaction(id);
       var viewModel = new StockTransactionEditViewModel { StockTransaction = dto };



       return PartialView("_EditModal", viewModel);
   }

   public async Task<IActionResult>DetailModal(int id)
   {
       var dto = await _stockTransactionAppService.GetStockTransaction(id);

       var viewModel = new StockTransactionEditViewModel
       {
         StockTransaction = dto
       };


       return PartialView("_DetailModal",viewModel);
   }

        public async Task<IActionResult> ExportDataModal()
        {
            return PartialView("_ExportDataModal");
        }
        public async Task<IActionResult> ImportDataModal()
        {
            return PartialView("_ImportDataModal");
        }

        [HttpPost]
        public async Task<IActionResult> ImportData(IFormFile file)
        {
            if (file == null || file.Length <= 0)
                return Content("{\"success\": false, \"message\": \"File chưa được upload.\"}");

            var totalRecords = 0;
            var successfulImports = 0;
            var failedImports = 0;
            var errorList = new List<string>();

            try
            {
                var (listImport, listError) = await ParseFileAsync(file);
                totalRecords = listImport.Count;
                errorList = listError;

                foreach (var import in listImport)
                {
                    string checkError;
                    if (!import.Id.IsNullOrEmpty())
                    {
                        checkError = await _stockTransactionExporterAppService.CheckErrorUpdateDetail(import);
                        if (checkError.IsNullOrEmpty())
                        {
                            var updateDto = new StockTransactionEditDto()
                            {
                              Id = long.TryParse(import.Id, out var id) ? id : 0,
                              TransactionCode = import.TransactionCode,
                              TransactionType = int.TryParse(import.TransactionType, out var TransactionType) ? TransactionType : 0,
                              TransactionDate = DateTime.TryParse(import.TransactionDate, out var TransactionDate) ? TransactionDate : default,
                              FromWarehouseId = int.TryParse(import.FromWarehouseId, out var FromWarehouseId) ? FromWarehouseId : (int?)null,
                              ToWarehouseId = int.TryParse(import.ToWarehouseId, out var ToWarehouseId) ? ToWarehouseId : (int?)null,
                              SupplierId = int.TryParse(import.SupplierId, out var SupplierId) ? SupplierId : (int?)null,
                              ReferenceNumber = import.ReferenceNumber,
                              Note = import.Note,
                              Status = int.TryParse(import.Status, out var Status) ? Status : 0,

                            };
                            await _stockTransactionAppService.EditStockTransaction(updateDto);
                            successfulImports++;
                        }
                        else
                        {
                            failedImports++;
                            errorList.Add($"stockTransaction (Id: {import.Id}): {checkError}");
                        }
                    }
                    else
                    {
                        checkError = await _stockTransactionExporterAppService.CheckErrorCreateDetail(import);
                        if (checkError.IsNullOrEmpty())
                        {
                            var createDto = new StockTransactionCreatingInput()
                            {
                              TransactionCode = import.TransactionCode,
                              TransactionType = int.TryParse(import.TransactionType, out var TransactionType) ? TransactionType : 0,
                              TransactionDate = DateTime.TryParse(import.TransactionDate, out var TransactionDate) ? TransactionDate : default,
                              FromWarehouseId = int.TryParse(import.FromWarehouseId, out var FromWarehouseId) ? FromWarehouseId : (int?)null,
                              ToWarehouseId = int.TryParse(import.ToWarehouseId, out var ToWarehouseId) ? ToWarehouseId : (int?)null,
                              SupplierId = int.TryParse(import.SupplierId, out var SupplierId) ? SupplierId : (int?)null,
                              ReferenceNumber = import.ReferenceNumber,
                              Note = import.Note,
                              Status = int.TryParse(import.Status, out var Status) ? Status : 0,

                            };
                            await _stockTransactionAppService.CreateStockTransaction(createDto);
                            successfulImports++;
                        }
                        else
                        {
                            failedImports++;
                            errorList.Add($"stockTransaction (Name: {import.TransactionCode ?? "N/A"}): {checkError}");
                        }
                    }
                }
                return Content(JsonConvert.SerializeObject(new
                {
	                success = true,
	                message = "Upload file thành công.",
	                totalRecords,
	                successfulImports,
	                failedImports,
	                errors = errorList
                }), "application/json");
            }
            catch (Exception ex)
	          {
		          Console.WriteLine(ex.Message);
		          return Content(JsonConvert.SerializeObject(new
		          {
			          success = false,
			          message = "Có lỗi: " + ex.Message,
			          totalRecords,
			          successfulImports,
			          failedImports,
			          errors = errorList
		          }), "application/json");
	          }
        }

        private async Task<(List<StockTransactionImportDto> listImport, List<string> listError)> ParseFileAsync(IFormFile file)
        {
            var listImport = new List<StockTransactionImportDto>();
            var errorList = new List<string>();
            var fileExtension = Path.GetExtension(file.FileName).ToLower();

            if (fileExtension == ".json")
            {
                using var stream = file.OpenReadStream();
                using var reader = new StreamReader(stream);
                var fileContent = await reader.ReadToEndAsync();
                listImport = JsonConvert.DeserializeObject<List<StockTransactionImportDto>>(fileContent);
            }
            else if (fileExtension == ".xlsx")
            {
                using var memoryStream = new MemoryStream();
                file.CopyTo(memoryStream);
                memoryStream.Position = 0;

                var rawRows = MiniExcel.Query(memoryStream, useHeaderRow: true).ToList();
                using var filteredStream = new MemoryStream();
                MiniExcel.SaveAs(filteredStream, rawRows);
                filteredStream.Position = 0;

                try
                {
                    listImport = MiniExcel.Query<StockTransactionImportDto>(filteredStream).Where(row => !IsRowInvalid(row)).ToList();
                }
                catch (Exception ex)
                {
                    var errorDetails = ex.Message.Split(':');
                    var errorMsg = errorDetails.Length > 3 ? errorDetails[3].Trim() : "Lỗi không xác định";
                    errorList.Add($"Lỗi dòng {errorDetails[2].Trim().Split(',')[0]}: {errorMsg}");
                }
            }
            else
            {
                throw new Exception("Loại tệp không được hỗ trợ.");
            }
            return (listImport, errorList);
        }

        private bool IsRowInvalid(StockTransactionImportDto row)
        {
            return row == null || (
                
                string.IsNullOrWhiteSpace(row.TransactionCode)&&

                string.IsNullOrWhiteSpace(row.TransactionType)&&

                string.IsNullOrWhiteSpace(row.TransactionDate)&&

                string.IsNullOrWhiteSpace(row.FromWarehouseId)&&

                string.IsNullOrWhiteSpace(row.ToWarehouseId)&&

                string.IsNullOrWhiteSpace(row.SupplierId)&&

                string.IsNullOrWhiteSpace(row.ReferenceNumber)&&

                string.IsNullOrWhiteSpace(row.Note)&&

                string.IsNullOrWhiteSpace(row.Status)

            );
    }
 }
