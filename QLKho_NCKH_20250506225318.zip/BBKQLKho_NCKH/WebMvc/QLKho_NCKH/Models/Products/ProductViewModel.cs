﻿using QLKho_NCKH.Products.Dto;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.Products;
	public class ProductCreateViewModel
	{
		public ProductCreatingInput Product { get; set; }
	}

	public class ProductIndexViewModel
	{
		public ProductEditDto Product { get; set; }
	}

	public class ProductEditViewModel
	{
		public ProductEditDto Product { get; set; }
	}

