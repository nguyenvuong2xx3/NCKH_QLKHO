﻿using QLKho_NCKH.StockTransactions.Dto;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.StockTransactions;
	public class StockTransactionCreateViewModel
	{
		public StockTransactionCreatingInput StockTransaction { get; set; }
	}

	public class StockTransactionIndexViewModel
	{
		public StockTransactionEditDto StockTransaction { get; set; }
	}

	public class StockTransactionEditViewModel
	{
		public StockTransactionEditDto StockTransaction { get; set; }
	}

