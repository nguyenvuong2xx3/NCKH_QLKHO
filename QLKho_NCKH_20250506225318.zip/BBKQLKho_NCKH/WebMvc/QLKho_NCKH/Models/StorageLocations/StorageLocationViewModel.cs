﻿using QLKho_NCKH.StorageLocations.Dto;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.StorageLocations;
	public class StorageLocationCreateViewModel
	{
		public StorageLocationCreatingInput StorageLocation { get; set; }
	}

	public class StorageLocationIndexViewModel
	{
		public StorageLocationEditDto StorageLocation { get; set; }
	}

	public class StorageLocationEditViewModel
	{
		public StorageLocationEditDto StorageLocation { get; set; }
	}

