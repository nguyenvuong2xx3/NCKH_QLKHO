﻿using QLKho_NCKH.Categories.Dto;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.Categories;
	public class CategoryCreateViewModel
	{
		public CategoryCreatingInput Category { get; set; }
	}

	public class CategoryIndexViewModel
	{
		public CategoryEditDto Category { get; set; }
	}

	public class CategoryEditViewModel
	{
		public CategoryEditDto Category { get; set; }
	}

