﻿using QLKho_NCKH.InventoryItems.Dto;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.InventoryItems;
	public class InventoryItemCreateViewModel
	{
		public InventoryItemCreatingInput InventoryItem { get; set; }
	}

	public class InventoryItemIndexViewModel
	{
		public InventoryItemEditDto InventoryItem { get; set; }
	}

	public class InventoryItemEditViewModel
	{
		public InventoryItemEditDto InventoryItem { get; set; }
	}

