﻿using QLKho_NCKH.StockTransactionDetails.Dto;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.StockTransactionDetails;
	public class StockTransactionDetailCreateViewModel
	{
		public StockTransactionDetailCreatingInput StockTransactionDetail { get; set; }
	}

	public class StockTransactionDetailIndexViewModel
	{
		public StockTransactionDetailEditDto StockTransactionDetail { get; set; }
	}

	public class StockTransactionDetailEditViewModel
	{
		public StockTransactionDetailEditDto StockTransactionDetail { get; set; }
	}

