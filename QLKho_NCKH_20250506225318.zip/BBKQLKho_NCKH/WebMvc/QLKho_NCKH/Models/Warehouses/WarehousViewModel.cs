﻿using QLKho_NCKH.Warehouses.Dto;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.Warehouses;
	public class WarehousCreateViewModel
	{
		public WarehousCreatingInput Warehous { get; set; }
	}

	public class WarehousIndexViewModel
	{
		public WarehousEditDto Warehous { get; set; }
	}

	public class WarehousEditViewModel
	{
		public WarehousEditDto Warehous { get; set; }
	}

