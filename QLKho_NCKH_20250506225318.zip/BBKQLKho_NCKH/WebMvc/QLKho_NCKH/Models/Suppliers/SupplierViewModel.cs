﻿using QLKho_NCKH.Suppliers.Dto;

namespace QLKho_NCKH.QLKho_NCKH.Web.Areas.QLKho_NCKH.Models.Suppliers;
	public class SupplierCreateViewModel
	{
		public SupplierCreatingInput Supplier { get; set; }
	}

	public class SupplierIndexViewModel
	{
		public SupplierEditDto Supplier { get; set; }
	}

	public class SupplierEditViewModel
	{
		public SupplierEditDto Supplier { get; set; }
	}

