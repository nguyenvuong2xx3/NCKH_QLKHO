﻿(function () {
  $(function () {
		var _$categoryTable = $('#CategoryTable');
		var _categoryService = abp.services.app.category;
		var _categoryExporterService = abp.services.app.categoryExporter;
		var _selectedDateRangeEntityChange;
		var _selectedDateRange = (_selectedDateRangeEntityChange = {
		});
		var _permissions = {
			create: abp.auth.hasPermission('Pages.Administration.Categorys.Create'),
			edit: abp.auth.hasPermission('Pages.Administration.Categorys.Edit'),
			delete: abp.auth.hasPermission('Pages.Administration.Categorys.Delete'),
		};

		var _createModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/Categories/CreateModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Categories/_CreateModal.js',
			modalClass: 'CreateCategoryModal',
			modalType: 'modal-xl'
		});

		var _editModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/Categories/EditModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Categories/_EditModal.js',
			modalClass: 'EditCategoryModal',
			modalType: 'modal-xl'
		});

		var _detailModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/Categories/DetailModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Categories/_DetailModal.js',
			modalClass: 'DetailCategoryModal',
			modalType: 'modal-xl'
		});


		var _exportModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/Categories/ExportDataModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Categories/_ExportDataModal.js',
			modalClass: 'ExportDataModal',
			modalSize: 'modal-xl'
		});

		$('#ExportData').click(function (e) {
     e.preventDefault();
			_exportModal.open();
		});

  var _importModal = new app.ModalManager({
    viewUrl: abp.appPath + 'QLKho_NCKH/Categories/ImportDataModal',
    scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Categories/_ImportDataModal.js',
    modalClass: 'ImportDataModal',
    modalSize: 'modal-xl'
  });

  $('#ImportData').click(function (e) {
    e.preventDefault();
    _importModal.open();
  });


		$('#StartEndRange').daterangepicker({
			autoUpdateInput: false,
			opens: 'left',
			locale: {
				format: 'MM/DD/YYYY',
				applyLabel: 'Áp dụng',
				cancelLabel: 'Hủy bỏ',
				fromLabel: 'Từ',
				toLabel: 'Đến',
				customRangeLabel: 'Tùy chỉnh',
				daysOfWeek: ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'],
				monthNames: ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'],
				firstDay: 1
			}
			}, function (start, end, label) {
				_selectedDateRange.StatTime = start.format('YYYY-MM-DDT00:00:00Z');
				_selectedDateRange.EndTime = end.format('YYYY-MM-DDT00:00:00Z');
			});
		$('input#StartEndRange').on('apply.daterangepicker', function (ev, picker) {
				$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		});

		$('input#StartEndRange').on('cancel.daterangepicker', function (ev, picker) {
				$(this).val('');
		});

		$('input#StartEndRange').on('input', function () {
				var inputValue = $(this).val();
				if (!inputValue) {
				 _selectedDateRangeEntityChange = {
				 startDate: null,
				 endDate: null
				 };
			}
		});

		var getFilter = function () {
			var StatTime = _selectedDateRangeEntityChange.StatTime;
			var EndTime = _selectedDateRangeEntityChange.EndTime;
			let dataFilter = {};
			dataFilter.filter = $('#SearchTerm').val();
			dataFilter.startDate = StatTime;
			dataFilter.endDate = EndTime;


			return dataFilter;
		}

		var dataTable = _$categoryTable.DataTable({
			paging: true,
			serverSide: true,
			processing: true,
			info: true,
			listAction: {
			ajaxFunction: _categoryService.getCategories,
			inputFilter: getFilter
			},
	  columnDefs: [
		{
			targets: 0,
			data: null,
			orderable: false,
			autoWidth: false,
			defaultContent: '',
			rowAction: {
				 text:
					 '<i class="fa fa-cog"></i> <span class="d-none d-md-inline-block d-lg-inline-block d-xl-inline-block">' +
					 app.localize('Actions') +
					 '</span> <span class="caret"></span>',
				 items: [
					 {
							text: app.localize('Edit'),
							//visible: function () {
							//  return _permissions.edit;
							//},
							action: function (data) {
							 _editModal.open({ id: data.record.id });
							},
					  },
					  {
							text: app.localize('Detail'),
							 action: function (data) {
								_detailModal.open({ id: data.record.id });
							 },
					  },
					  {
							text: app.localize('Delete'),
							//visible: function () {
							//  return _permissions.delete;
							//},
							action: function (data) {
								deleteCategory(data);
					  },
					 },
				 ],
			},
			},
			{
					targets: 1,
					orderable: true,
					data: "name"
			},
			{
					targets: 2,
					orderable: true,
					data: "description"
			},
			{
					targets: 3,
					orderable: true,
					data: "parentId"
			},

			]
	});

		function getCategorys() {
			dataTable.ajax.reload();
		}



		function deleteCategory(data) {
				abp.message.confirm(
				app.localize('Delete'),
				app.localize('AreYouSure'),
				function (isConfirmed) {
					if (isConfirmed) {
					_categoryService.deleteCategory(
					 data.record.id
					).done(function () {
						getCategorys(true);
						abp.notify.success(app.localize('SuccessfullyDeleted'));
					});
					}
				},
				{ confirmButtonText: 'Xóa', confirmButtonColor: '#dc3545', cancelButtonText: 'Hủy' }
				);
		}

		$('#ShowAdvancedFiltersSpan').click(function () {
			$('#ShowAdvancedFiltersSpan').hide();
			$('#HideAdvancedFiltersSpan').show();
			$('#AdvacedAuditFiltersArea').slideDown();
		});

		$('#HideAdvancedFiltersSpan').click(function () {
			$('#HideAdvancedFiltersSpan').hide();
			$('#ShowAdvancedFiltersSpan').show();
			$('#AdvacedAuditFiltersArea').slideUp();
		});

		$('#CreateNewButton').click(function () {
			_createModal.open();
		});

		$('#RefreshListButton').click(function (e) {
			e.preventDefault();
			getCategorys();
		});

		abp.event.on('app.updateCategoryModalSaved', function () {
			getCategorys(true);
		});

		$('#Search').click(function (e) {
			e.preventDefault();
			getCategorys();
		});

		$('#SearchTerm').on('keydown', function (e) {
			if (e.keyCode !== 13) {
			return;
		}
			e.preventDefault();
			getCategorys();
		});

		jQuery(document).ready(function () {
			$("#SearchTerm").focus();
		});
  });
})();
