﻿(function () {
    app.modals.DetailCategoryModal = function () {

    };
})();
