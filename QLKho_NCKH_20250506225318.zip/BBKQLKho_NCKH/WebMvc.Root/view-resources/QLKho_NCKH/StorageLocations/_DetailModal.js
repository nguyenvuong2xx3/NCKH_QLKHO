﻿(function () {
    app.modals.DetailStorageLocationModal = function () {

    };
})();
