﻿(function () {
    app.modals.DetailWarehousModal = function () {

    };
})();
