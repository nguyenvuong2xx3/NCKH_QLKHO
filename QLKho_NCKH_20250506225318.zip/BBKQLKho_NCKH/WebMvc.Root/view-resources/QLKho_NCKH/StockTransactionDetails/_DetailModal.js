﻿(function () {
    app.modals.DetailStockTransactionDetailModal = function () {

    };
})();
