﻿(function () {
  $(function () {
		var _$productTable = $('#ProductTable');
		var _productService = abp.services.app.product;
		var _productExporterService = abp.services.app.productExporter;
		var _selectedDateRangeEntityChange;
		var _selectedDateRange = (_selectedDateRangeEntityChange = {
		});
		var _permissions = {
			create: abp.auth.hasPermission('Pages.Administration.Products.Create'),
			edit: abp.auth.hasPermission('Pages.Administration.Products.Edit'),
			delete: abp.auth.hasPermission('Pages.Administration.Products.Delete'),
		};

		var _createModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/Products/CreateModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Products/_CreateModal.js',
			modalClass: 'CreateProductModal',
			modalType: 'modal-xl'
		});

		var _editModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/Products/EditModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Products/_EditModal.js',
			modalClass: 'EditProductModal',
			modalType: 'modal-xl'
		});

		var _detailModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/Products/DetailModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Products/_DetailModal.js',
			modalClass: 'DetailProductModal',
			modalType: 'modal-xl'
		});


		var _exportModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/Products/ExportDataModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Products/_ExportDataModal.js',
			modalClass: 'ExportDataModal',
			modalSize: 'modal-xl'
		});

		$('#ExportData').click(function (e) {
     e.preventDefault();
			_exportModal.open();
		});

  var _importModal = new app.ModalManager({
    viewUrl: abp.appPath + 'QLKho_NCKH/Products/ImportDataModal',
    scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/Products/_ImportDataModal.js',
    modalClass: 'ImportDataModal',
    modalSize: 'modal-xl'
  });

  $('#ImportData').click(function (e) {
    e.preventDefault();
    _importModal.open();
  });


		$('#StartEndRange').daterangepicker({
			autoUpdateInput: false,
			opens: 'left',
			locale: {
				format: 'MM/DD/YYYY',
				applyLabel: 'Áp dụng',
				cancelLabel: 'Hủy bỏ',
				fromLabel: 'Từ',
				toLabel: 'Đến',
				customRangeLabel: 'Tùy chỉnh',
				daysOfWeek: ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'],
				monthNames: ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'],
				firstDay: 1
			}
			}, function (start, end, label) {
				_selectedDateRange.StatTime = start.format('YYYY-MM-DDT00:00:00Z');
				_selectedDateRange.EndTime = end.format('YYYY-MM-DDT00:00:00Z');
			});
		$('input#StartEndRange').on('apply.daterangepicker', function (ev, picker) {
				$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		});

		$('input#StartEndRange').on('cancel.daterangepicker', function (ev, picker) {
				$(this).val('');
		});

		$('input#StartEndRange').on('input', function () {
				var inputValue = $(this).val();
				if (!inputValue) {
				 _selectedDateRangeEntityChange = {
				 startDate: null,
				 endDate: null
				 };
			}
		});

		var getFilter = function () {
			var StatTime = _selectedDateRangeEntityChange.StatTime;
			var EndTime = _selectedDateRangeEntityChange.EndTime;
			let dataFilter = {};
			dataFilter.filter = $('#SearchTerm').val();
			dataFilter.startDate = StatTime;
			dataFilter.endDate = EndTime;


			return dataFilter;
		}

		var dataTable = _$productTable.DataTable({
			paging: true,
			serverSide: true,
			processing: true,
			info: true,
			listAction: {
			ajaxFunction: _productService.getProducts,
			inputFilter: getFilter
			},
	  columnDefs: [
		{
			targets: 0,
			data: null,
			orderable: false,
			autoWidth: false,
			defaultContent: '',
			rowAction: {
				 text:
					 '<i class="fa fa-cog"></i> <span class="d-none d-md-inline-block d-lg-inline-block d-xl-inline-block">' +
					 app.localize('Actions') +
					 '</span> <span class="caret"></span>',
				 items: [
					 {
							text: app.localize('Edit'),
							//visible: function () {
							//  return _permissions.edit;
							//},
							action: function (data) {
							 _editModal.open({ id: data.record.id });
							},
					  },
					  {
							text: app.localize('Detail'),
							 action: function (data) {
								_detailModal.open({ id: data.record.id });
							 },
					  },
					  {
							text: app.localize('Delete'),
							//visible: function () {
							//  return _permissions.delete;
							//},
							action: function (data) {
								deleteProduct(data);
					  },
					 },
				 ],
			},
			},
			{
					targets: 1,
					orderable: true,
					data: "code"
			},
			{
					targets: 2,
					orderable: true,
					data: "name"
			},
			{
					targets: 3,
					orderable: true,
					data: "description"
			},
			{
					targets: 4,
					orderable: true,
					data: "categoryId"
			},
			{
					targets: 5,
					orderable: true,
					data: "barcode"
			},
			{
					targets: 6,
					orderable: true,
					data: "unit"
			},
			{
					targets: 7,
					orderable: true,
					data: "weight"
			},
			{
					targets: 8,
					orderable: true,
					data: "volume"
			},
			{
					targets: 9,
					orderable: true,
					data: "isActive"
			},
			{
					targets: 10,
					orderable: true,
					data: "supplierId"
			},
			{
					targets: 11,
					orderable: true,
					data: "image"
			},

			]
	});

		function getProducts() {
			dataTable.ajax.reload();
		}



		function deleteProduct(data) {
				abp.message.confirm(
				app.localize('Delete'),
				app.localize('AreYouSure'),
				function (isConfirmed) {
					if (isConfirmed) {
					_productService.deleteProduct(
					 data.record.id
					).done(function () {
						getProducts(true);
						abp.notify.success(app.localize('SuccessfullyDeleted'));
					});
					}
				},
				{ confirmButtonText: 'Xóa', confirmButtonColor: '#dc3545', cancelButtonText: 'Hủy' }
				);
		}

		$('#ShowAdvancedFiltersSpan').click(function () {
			$('#ShowAdvancedFiltersSpan').hide();
			$('#HideAdvancedFiltersSpan').show();
			$('#AdvacedAuditFiltersArea').slideDown();
		});

		$('#HideAdvancedFiltersSpan').click(function () {
			$('#HideAdvancedFiltersSpan').hide();
			$('#ShowAdvancedFiltersSpan').show();
			$('#AdvacedAuditFiltersArea').slideUp();
		});

		$('#CreateNewButton').click(function () {
			_createModal.open();
		});

		$('#RefreshListButton').click(function (e) {
			e.preventDefault();
			getProducts();
		});

		abp.event.on('app.updateProductModalSaved', function () {
			getProducts(true);
		});

		$('#Search').click(function (e) {
			e.preventDefault();
			getProducts();
		});

		$('#SearchTerm').on('keydown', function (e) {
			if (e.keyCode !== 13) {
			return;
		}
			e.preventDefault();
			getProducts();
		});

		jQuery(document).ready(function () {
			$("#SearchTerm").focus();
		});
  });
})();
