﻿(function () {
    app.modals.EditProductModal = function () {
        var _modalManager;
        var _productService = abp.services.app.product;
        var _$form = null;


        this.init = function (modalManager) {
            _modalManager = modalManager;

            _$form = _modalManager.getModal().find('form[name=EditProductForm]');
            _$form.validate({
                validClass: "valid",
                errorClass: "invalid-feedback",
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid').removeClass('is-valid');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-valid').removeClass('is-invalid');
                },
                rules: {

                },
                messages: {

                },
                errorPlacement: function (error, element) {
                    if (element.closest('.input-group').length) {
                        error.addClass('text-danger');
                        error.insertAfter(element.closest('.input-group'));
                    } else if (element.closest('.form-check').length) {
                        error.addClass('text-danger');
                        error.appendTo(element.closest('.form-check'));
                    } else {
                        error.insertAfter(element);
                    }
                },
                success: function (label, element) {
                    $(element).next('.invalid-feedback').remove();
                }
            });
            _$form.inputMaskForm();





        };

        this.save = function () {
            if (!_$form.valid()) {
                return;
            }

            var dataInput = _$form.serializeFormToObject();
            ;
                     dataInput.IsActive = $('#IsActive').is(':checked') ? true : false;


            _modalManager.setBusy(true);
            _productService
                .editProduct(dataInput)
                .done(function (result) {
                    abp.event.trigger('app.updateProductModalSaved');
                    abp.notify.info(app.localize('SavedSuccessfully'));
                    _modalManager.close();
                })
                .always(function () {
                    _modalManager.setBusy(false);
                });
        };
    };
})();
