﻿(function () {
    app.modals.DetailProductModal = function () {

    };
})();
