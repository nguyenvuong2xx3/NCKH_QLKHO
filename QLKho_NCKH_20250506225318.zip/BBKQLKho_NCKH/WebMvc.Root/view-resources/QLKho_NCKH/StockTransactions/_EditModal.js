﻿(function () {
    app.modals.EditStockTransactionModal = function () {
        var _modalManager;
        var _stockTransactionService = abp.services.app.stockTransaction;
        var _$form = null;


        this.init = function (modalManager) {
            _modalManager = modalManager;
                _modalManager.getModal().find('.date-picker').daterangepicker({
                            singleDatePicker: true,
                            showDropdowns: true,
                            autoUpdateInput: false,
                            timePicker: false,
                            timePicker24Hour: false,
                            timePickerSeconds: false,
                            autoApply: true,
                            parentEl: $(_modalManager.getModal())
                        });
                        _modalManager.getModal().find('.date-picker').on('apply.daterangepicker', function (ev, picker) {
                            $(this).val(picker.startDate.format("L"));
                        });
            _$form = _modalManager.getModal().find('form[name=EditStockTransactionForm]');
            _$form.validate({
                validClass: "valid",
                errorClass: "invalid-feedback",
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid').removeClass('is-valid');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-valid').removeClass('is-invalid');
                },
                rules: {

                },
                messages: {

                },
                errorPlacement: function (error, element) {
                    if (element.closest('.input-group').length) {
                        error.addClass('text-danger');
                        error.insertAfter(element.closest('.input-group'));
                    } else if (element.closest('.form-check').length) {
                        error.addClass('text-danger');
                        error.appendTo(element.closest('.form-check'));
                    } else {
                        error.insertAfter(element);
                    }
                },
                success: function (label, element) {
                    $(element).next('.invalid-feedback').remove();
                }
            });
            _$form.inputMaskForm();





        };

        this.save = function () {
            if (!_$form.valid()) {
                return;
            }

            var dataInput = _$form.serializeFormToObject();
            ;

               if (dataInput.TransactionDate) {
              dataInput.TransactionDate = moment(dataInput.TransactionDate, 'DD/MM/YYYY HH:mm').format('YYYY-MM-DDTHH:mm:ss'); // ISO 8601 format
            }

            _modalManager.setBusy(true);
            _stockTransactionService
                .editStockTransaction(dataInput)
                .done(function (result) {
                    abp.event.trigger('app.updateStockTransactionModalSaved');
                    abp.notify.info(app.localize('SavedSuccessfully'));
                    _modalManager.close();
                })
                .always(function () {
                    _modalManager.setBusy(false);
                });
        };
    };
})();
