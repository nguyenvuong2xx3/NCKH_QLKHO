﻿
	(function () {
  app.modals.ExportDataModal = function () {
    var _modalManager;
		var _stockTransactionService = abp.services.app.stockTransactionExporter;
    var _$form = null;
var _selectedDateRangeEntityChange;
var _selectedDateRange = (_selectedDateRangeEntityChange = {
});
    this.init = function (modalManager) {
      _modalManager = modalManager;



      _$form = _modalManager.getModal().find('form[name=ExportStockTransactionForm]');
   _$form.validate({
    validClass: "valid",  // default
    errorClass: "invalid-feedback", // default is "error"
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid').removeClass('is-valid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).addClass('is-valid').removeClass('is-invalid');
    },
    rules: {
      SelectFileFormat: {
        required: true,
      },
    },
    messages: {
      SelectFileFormat: {
        required: 'Định dạng file phải được chọn',
      },
    },
  });
  _$form.inputMaskForm();
  if ($('#alloption').is(':checked') == true) {
    $('.input-options').find("input:checkbox:not(:checked)").prop("checked", true);
  } else {
    $('.input-options').find("input:checkbox").prop("checked", false);
  }
  $('#alloption').on('change', function () {
    if ($(this).is(':checked') == true) {
      $('.input-options').find("input:checkbox:not(:checked)").prop("checked", true);
    } else {
      $('.input-options').find("input:checkbox").prop("checked", false);
    }
  });
  $('.input-options').find("input:checkbox").on('change', function () {
    if ($('.input-options').find("input:checkbox:not(:checked)").length > 0) {
      $('#alloption').prop("checked", false)
    } else {
      $('#alloption').prop("checked", true)
    }
  })

};

    this.save = function () {
    if (!_$form.valid()) {
  return;
}

if ($('.input-options').find("input:checkbox:checked").length == 0) {
  abp.message.error('Vui lòng chọn trường thông tin để xuất file');
  return;
}
 var  maDiaChi,diaChi;




     var filter = function () {
  var datafilter = {};
  datafilter.filter = $('#SearchTerm').val();
  datafilter.startDate = _selectedDateRangeEntityChange.StatTime;
  datafilter.endDate = _selectedDateRangeEntityChange.EndTime;
  datafilter.diaChi = diaChi;
  datafilter.maDiaChi = maDiaChi;
  datafilter.exportFileType = $("#SelectFileFormat").val();

	datafilter.IsDisplayTransactionCode = $('input[name="IsDisplayTransactionCode"]').is(":checked");datafilter.IsDisplayTransactionType = $('input[name="IsDisplayTransactionType"]').is(":checked");datafilter.IsDisplayTransactionDate = $('input[name="IsDisplayTransactionDate"]').is(":checked");datafilter.IsDisplayFromWarehouseId = $('input[name="IsDisplayFromWarehouseId"]').is(":checked");datafilter.IsDisplayToWarehouseId = $('input[name="IsDisplayToWarehouseId"]').is(":checked");datafilter.IsDisplaySupplierId = $('input[name="IsDisplaySupplierId"]').is(":checked");datafilter.IsDisplayReferenceNumber = $('input[name="IsDisplayReferenceNumber"]').is(":checked");datafilter.IsDisplayNote = $('input[name="IsDisplayNote"]').is(":checked");datafilter.IsDisplayStatus = $('input[name="IsDisplayStatus"]').is(":checked");
  return datafilter
}

      _modalManager.setBusy(true);
      _stockTransactionService
        .exportData(filter())
        .done(function (result) {
  app.downloadTempFile(result);
}).always(function () {
  _modalManager.setBusy(false);
});
    };
  };
})();
