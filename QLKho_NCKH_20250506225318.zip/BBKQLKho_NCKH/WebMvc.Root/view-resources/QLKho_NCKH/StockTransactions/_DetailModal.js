﻿(function () {
    app.modals.DetailStockTransactionModal = function () {

    };
})();
