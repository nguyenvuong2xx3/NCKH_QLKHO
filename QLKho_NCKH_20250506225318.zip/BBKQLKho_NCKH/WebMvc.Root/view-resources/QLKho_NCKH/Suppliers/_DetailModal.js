﻿(function () {
    app.modals.DetailSupplierModal = function () {

    };
})();
