﻿
	(function () {
  app.modals.ExportDataModal = function () {
    var _modalManager;
		var _supplierService = abp.services.app.supplierExporter;
    var _$form = null;
var _selectedDateRangeEntityChange;
var _selectedDateRange = (_selectedDateRangeEntityChange = {
});
    this.init = function (modalManager) {
      _modalManager = modalManager;



      _$form = _modalManager.getModal().find('form[name=ExportSupplierForm]');
   _$form.validate({
    validClass: "valid",  // default
    errorClass: "invalid-feedback", // default is "error"
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid').removeClass('is-valid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).addClass('is-valid').removeClass('is-invalid');
    },
    rules: {
      SelectFileFormat: {
        required: true,
      },
    },
    messages: {
      SelectFileFormat: {
        required: 'Định dạng file phải được chọn',
      },
    },
  });
  _$form.inputMaskForm();
  if ($('#alloption').is(':checked') == true) {
    $('.input-options').find("input:checkbox:not(:checked)").prop("checked", true);
  } else {
    $('.input-options').find("input:checkbox").prop("checked", false);
  }
  $('#alloption').on('change', function () {
    if ($(this).is(':checked') == true) {
      $('.input-options').find("input:checkbox:not(:checked)").prop("checked", true);
    } else {
      $('.input-options').find("input:checkbox").prop("checked", false);
    }
  });
  $('.input-options').find("input:checkbox").on('change', function () {
    if ($('.input-options').find("input:checkbox:not(:checked)").length > 0) {
      $('#alloption').prop("checked", false)
    } else {
      $('#alloption').prop("checked", true)
    }
  })

};

    this.save = function () {
    if (!_$form.valid()) {
  return;
}

if ($('.input-options').find("input:checkbox:checked").length == 0) {
  abp.message.error('Vui lòng chọn trường thông tin để xuất file');
  return;
}
 var  maDiaChi,diaChi;




     var filter = function () {
  var datafilter = {};
  datafilter.filter = $('#SearchTerm').val();
  datafilter.startDate = _selectedDateRangeEntityChange.StatTime;
  datafilter.endDate = _selectedDateRangeEntityChange.EndTime;
  datafilter.diaChi = diaChi;
  datafilter.maDiaChi = maDiaChi;
  datafilter.exportFileType = $("#SelectFileFormat").val();

	datafilter.IsDisplayCode = $('input[name="IsDisplayCode"]').is(":checked");datafilter.IsDisplayName = $('input[name="IsDisplayName"]').is(":checked");datafilter.IsDisplayAddress = $('input[name="IsDisplayAddress"]').is(":checked");datafilter.IsDisplayPhoneNumber = $('input[name="IsDisplayPhoneNumber"]').is(":checked");datafilter.IsDisplayEmail = $('input[name="IsDisplayEmail"]').is(":checked");datafilter.IsDisplayTaxCode = $('input[name="IsDisplayTaxCode"]').is(":checked");datafilter.IsDisplayIsActive = $('input[name="IsDisplayIsActive"]').is(":checked");
  return datafilter
}

      _modalManager.setBusy(true);
      _supplierService
        .exportData(filter())
        .done(function (result) {
  app.downloadTempFile(result);
}).always(function () {
  _modalManager.setBusy(false);
});
    };
  };
})();
