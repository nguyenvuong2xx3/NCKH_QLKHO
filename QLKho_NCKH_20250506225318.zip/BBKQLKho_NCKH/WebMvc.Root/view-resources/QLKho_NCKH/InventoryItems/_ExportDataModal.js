﻿
	(function () {
  app.modals.ExportDataModal = function () {
    var _modalManager;
		var _inventoryItemService = abp.services.app.inventoryItemExporter;
    var _$form = null;
var _selectedDateRangeEntityChange;
var _selectedDateRange = (_selectedDateRangeEntityChange = {
});
    this.init = function (modalManager) {
      _modalManager = modalManager;



      _$form = _modalManager.getModal().find('form[name=ExportInventoryItemForm]');
   _$form.validate({
    validClass: "valid",  // default
    errorClass: "invalid-feedback", // default is "error"
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid').removeClass('is-valid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).addClass('is-valid').removeClass('is-invalid');
    },
    rules: {
      SelectFileFormat: {
        required: true,
      },
    },
    messages: {
      SelectFileFormat: {
        required: 'Định dạng file phải được chọn',
      },
    },
  });
  _$form.inputMaskForm();
  if ($('#alloption').is(':checked') == true) {
    $('.input-options').find("input:checkbox:not(:checked)").prop("checked", true);
  } else {
    $('.input-options').find("input:checkbox").prop("checked", false);
  }
  $('#alloption').on('change', function () {
    if ($(this).is(':checked') == true) {
      $('.input-options').find("input:checkbox:not(:checked)").prop("checked", true);
    } else {
      $('.input-options').find("input:checkbox").prop("checked", false);
    }
  });
  $('.input-options').find("input:checkbox").on('change', function () {
    if ($('.input-options').find("input:checkbox:not(:checked)").length > 0) {
      $('#alloption').prop("checked", false)
    } else {
      $('#alloption').prop("checked", true)
    }
  })

};

    this.save = function () {
    if (!_$form.valid()) {
  return;
}

if ($('.input-options').find("input:checkbox:checked").length == 0) {
  abp.message.error('Vui lòng chọn trường thông tin để xuất file');
  return;
}
 var  maDiaChi,diaChi;




     var filter = function () {
  var datafilter = {};
  datafilter.filter = $('#SearchTerm').val();
  datafilter.startDate = _selectedDateRangeEntityChange.StatTime;
  datafilter.endDate = _selectedDateRangeEntityChange.EndTime;
  datafilter.diaChi = diaChi;
  datafilter.maDiaChi = maDiaChi;
  datafilter.exportFileType = $("#SelectFileFormat").val();

	datafilter.IsDisplayProductId = $('input[name="IsDisplayProductId"]').is(":checked");datafilter.IsDisplayStorageLocationId = $('input[name="IsDisplayStorageLocationId"]').is(":checked");datafilter.IsDisplayQuantity = $('input[name="IsDisplayQuantity"]').is(":checked");datafilter.IsDisplayReservedQuantity = $('input[name="IsDisplayReservedQuantity"]').is(":checked");datafilter.IsDisplayUnitPrice = $('input[name="IsDisplayUnitPrice"]').is(":checked");
  return datafilter
}

      _modalManager.setBusy(true);
      _inventoryItemService
        .exportData(filter())
        .done(function (result) {
  app.downloadTempFile(result);
}).always(function () {
  _modalManager.setBusy(false);
});
    };
  };
})();
