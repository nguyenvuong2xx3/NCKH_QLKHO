﻿(function () {
  $(function () {
		var _$inventoryItemTable = $('#InventoryItemTable');
		var _inventoryItemService = abp.services.app.inventoryItem;
		var _inventoryItemExporterService = abp.services.app.inventoryItemExporter;
		var _selectedDateRangeEntityChange;
		var _selectedDateRange = (_selectedDateRangeEntityChange = {
		});
		var _permissions = {
			create: abp.auth.hasPermission('Pages.Administration.InventoryItems.Create'),
			edit: abp.auth.hasPermission('Pages.Administration.InventoryItems.Edit'),
			delete: abp.auth.hasPermission('Pages.Administration.InventoryItems.Delete'),
		};

		var _createModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/InventoryItems/CreateModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/InventoryItems/_CreateModal.js',
			modalClass: 'CreateInventoryItemModal',
			modalType: 'modal-xl'
		});

		var _editModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/InventoryItems/EditModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/InventoryItems/_EditModal.js',
			modalClass: 'EditInventoryItemModal',
			modalType: 'modal-xl'
		});

		var _detailModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/InventoryItems/DetailModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/InventoryItems/_DetailModal.js',
			modalClass: 'DetailInventoryItemModal',
			modalType: 'modal-xl'
		});


		var _exportModal = new app.ModalManager({
			viewUrl: abp.appPath + 'QLKho_NCKH/InventoryItems/ExportDataModal',
			scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/InventoryItems/_ExportDataModal.js',
			modalClass: 'ExportDataModal',
			modalSize: 'modal-xl'
		});

		$('#ExportData').click(function (e) {
     e.preventDefault();
			_exportModal.open();
		});

  var _importModal = new app.ModalManager({
    viewUrl: abp.appPath + 'QLKho_NCKH/InventoryItems/ImportDataModal',
    scriptUrl: abp.appPath + 'view-resources/QLKho_NCKH/InventoryItems/_ImportDataModal.js',
    modalClass: 'ImportDataModal',
    modalSize: 'modal-xl'
  });

  $('#ImportData').click(function (e) {
    e.preventDefault();
    _importModal.open();
  });


		$('#StartEndRange').daterangepicker({
			autoUpdateInput: false,
			opens: 'left',
			locale: {
				format: 'MM/DD/YYYY',
				applyLabel: 'Áp dụng',
				cancelLabel: 'Hủy bỏ',
				fromLabel: 'Từ',
				toLabel: 'Đến',
				customRangeLabel: 'Tùy chỉnh',
				daysOfWeek: ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'],
				monthNames: ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'],
				firstDay: 1
			}
			}, function (start, end, label) {
				_selectedDateRange.StatTime = start.format('YYYY-MM-DDT00:00:00Z');
				_selectedDateRange.EndTime = end.format('YYYY-MM-DDT00:00:00Z');
			});
		$('input#StartEndRange').on('apply.daterangepicker', function (ev, picker) {
				$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		});

		$('input#StartEndRange').on('cancel.daterangepicker', function (ev, picker) {
				$(this).val('');
		});

		$('input#StartEndRange').on('input', function () {
				var inputValue = $(this).val();
				if (!inputValue) {
				 _selectedDateRangeEntityChange = {
				 startDate: null,
				 endDate: null
				 };
			}
		});

		var getFilter = function () {
			var StatTime = _selectedDateRangeEntityChange.StatTime;
			var EndTime = _selectedDateRangeEntityChange.EndTime;
			let dataFilter = {};
			dataFilter.filter = $('#SearchTerm').val();
			dataFilter.startDate = StatTime;
			dataFilter.endDate = EndTime;


			return dataFilter;
		}

		var dataTable = _$inventoryItemTable.DataTable({
			paging: true,
			serverSide: true,
			processing: true,
			info: true,
			listAction: {
			ajaxFunction: _inventoryItemService.getInventoryItems,
			inputFilter: getFilter
			},
	  columnDefs: [
		{
			targets: 0,
			data: null,
			orderable: false,
			autoWidth: false,
			defaultContent: '',
			rowAction: {
				 text:
					 '<i class="fa fa-cog"></i> <span class="d-none d-md-inline-block d-lg-inline-block d-xl-inline-block">' +
					 app.localize('Actions') +
					 '</span> <span class="caret"></span>',
				 items: [
					 {
							text: app.localize('Edit'),
							//visible: function () {
							//  return _permissions.edit;
							//},
							action: function (data) {
							 _editModal.open({ id: data.record.id });
							},
					  },
					  {
							text: app.localize('Detail'),
							 action: function (data) {
								_detailModal.open({ id: data.record.id });
							 },
					  },
					  {
							text: app.localize('Delete'),
							//visible: function () {
							//  return _permissions.delete;
							//},
							action: function (data) {
								deleteInventoryItem(data);
					  },
					 },
				 ],
			},
			},
			{
					targets: 1,
					orderable: true,
					data: "productId"
			},
			{
					targets: 2,
					orderable: true,
					data: "storageLocationId"
			},
			{
					targets: 3,
					orderable: true,
					data: "quantity"
			},
			{
					targets: 4,
					orderable: true,
					data: "reservedQuantity"
			},
			{
					targets: 5,
					orderable: true,
					data: "unitPrice"
			},

			]
	});

		function getInventoryItems() {
			dataTable.ajax.reload();
		}



		function deleteInventoryItem(data) {
				abp.message.confirm(
				app.localize('Delete'),
				app.localize('AreYouSure'),
				function (isConfirmed) {
					if (isConfirmed) {
					_inventoryItemService.deleteInventoryItem(
					 data.record.id
					).done(function () {
						getInventoryItems(true);
						abp.notify.success(app.localize('SuccessfullyDeleted'));
					});
					}
				},
				{ confirmButtonText: 'Xóa', confirmButtonColor: '#dc3545', cancelButtonText: 'Hủy' }
				);
		}

		$('#ShowAdvancedFiltersSpan').click(function () {
			$('#ShowAdvancedFiltersSpan').hide();
			$('#HideAdvancedFiltersSpan').show();
			$('#AdvacedAuditFiltersArea').slideDown();
		});

		$('#HideAdvancedFiltersSpan').click(function () {
			$('#HideAdvancedFiltersSpan').hide();
			$('#ShowAdvancedFiltersSpan').show();
			$('#AdvacedAuditFiltersArea').slideUp();
		});

		$('#CreateNewButton').click(function () {
			_createModal.open();
		});

		$('#RefreshListButton').click(function (e) {
			e.preventDefault();
			getInventoryItems();
		});

		abp.event.on('app.updateInventoryItemModalSaved', function () {
			getInventoryItems(true);
		});

		$('#Search').click(function (e) {
			e.preventDefault();
			getInventoryItems();
		});

		$('#SearchTerm').on('keydown', function (e) {
			if (e.keyCode !== 13) {
			return;
		}
			e.preventDefault();
			getInventoryItems();
		});

		jQuery(document).ready(function () {
			$("#SearchTerm").focus();
		});
  });
})();
