﻿(function () {
    app.modals.DetailInventoryItemModal = function () {

    };
})();
